#!/bin/bash
# Legion (D-57, D-71): the keyboard layout of /etc/default/keyboard in the
# initrd, before the disk passphrase prompt.
#
# The Debian module console-setup puts into the initrd a small setupcon with
# the console keymap and font, but starts it only through the dracut
# initqueue. In an initrd with systemd the initqueue runs its jobs only while
# dracut waits for a device named on the kernel command line, for example
# root= or rd.luks.uuid=. Legion finds its root partition without them, so
# the prompt kept the keymap of the kernel (us). This module starts the same
# setupcon from a systemd unit, before any passphrase prompt.

# called by dracut
check() {
    require_binaries setupcon || return 1
    return 0
}

# called by dracut
depends() {
    echo console-setup systemd
    return 0
}

# called by dracut
install() {
    inst_simple "$moddir/legion-console-setup.service" "$systemdsystemunitdir/legion-console-setup.service"
    $SYSTEMCTL -q --root "$initdir" add-wants sysinit.target legion-console-setup.service
}
