# legion_install: the Legion installer without its user interface (D-59, D-69
# to D-78). The text installer legion-install and the window
# legion-install-gui ask the questions and show the progress; this module
# knows the computer, checks the answers and installs Legion with install().
# It erases the whole disk you choose:
#
#   1. systemd-repart creates an EFI system partition of 1 GiB and a root
#      partition on the rest of the disk, formatted with ext4 and, if you
#      choose it, encrypted with LUKS2 (D-72), and copies into it the root
#      partition of the USB stick (definitions in repart.d/ and encryption/
#      next to this file);
#   2. the new system gets its language, keyboard layout, time zone, computer
#      name, account and swap, and loses the packages of the live session;
#   3. bootctl and kernel-install, run inside the new system, install
#      systemd-boot and a boot menu entry with an initrd built by dracut (D-57);
#   4. dpkg --verify checks the copied package files (D-56, D-59);
#   5. on an encrypted disk, systemd-cryptenroll replaces the temporary key
#      with your passphrase and a recovery key, and optionally adds a FIDO2
#      security key.
#
# The root partition of the USB stick is only read: in RAM mode the installer
# mounts it read-only, in overlay mode it uses the read-only layer of the
# running system. Changes made in the live session, for example the live
# account or saved Wi-Fi passwords, do not reach the new system.
#
# All mounts happen in a private mount namespace of the thread that runs
# install(), so the desktop does not see them and they disappear when the
# installer ends. A log without passwords and keys is kept in
# /run/legion-install/install.log and copied to /var/log/legion-install.log on
# the new system.

import fcntl
import json
import os
import re
import secrets
import shlex
import shutil
import socket
import subprocess
import time
from pathlib import Path

VERSION = "4"

LIBRARY = Path("/usr/lib/legion-installer")
DEFINITIONS = LIBRARY / "repart.d"
# A drop-in of 20-root.conf that turns encryption on (D-72). systemd-repart
# reads drop-ins from every folder given with --definitions=.
ENCRYPTION_DEFINITIONS = LIBRARY / "encryption"
WORK = Path("/run/legion-install")
SOURCE = WORK / "source"
SOURCE_ESP = WORK / "source-esp"
TARGET = WORK / "target"
KEY_FILE = WORK / "disk-key"
LOG_FILE = WORK / "install.log"
LOCK_FILE = Path("/run/legion-install.lock")
TARGET_VOLUME = "legion-target"
TARGET_DEVICE = Path("/dev/mapper") / TARGET_VOLUME
BOOT_PARTITION = Path("/dev/gpt-auto-root")
OVERLAY_LOWER = Path("/run/legion-live/lower")
# Password questions of systemd programs, for password agents
# (https://systemd.io/PASSWORD_AGENTS/).
ASK_PASSWORD = Path("/run/systemd/ask-password")

ESP_TYPE = "c12a7328-f81f-11d2-ba4b-00a0c93ec93b"
ROOT_TYPE = "4f68bce3-e8cd-4db1-96e7-fbcaf984b709"  # root partition, x86-64
MIN_DISK_SIZE = 16 * 1024**3
DEFAULT_SWAP_FILE_GIB = 4
# Groups of 8 letters of the recovery key that you type from your note, chosen
# at random, to catch mistakes in writing it down (D-75).
RECOVERY_KEY_CHECKS = 2
LIVE_PACKAGES = ["legion-live", "legion-installer"]
ACCOUNT_GROUPS = ["sudo"]
# The image turns zram off with this link to /dev/null (D-48).
ZRAM_MASK = "etc/systemd/zram-generator.conf"
# On an encrypted disk the installer masks this unit (D-72). systemd-repart
# 257 marks every root partition for growing, even with GrowFileSystem=no,
# and systemd-growfs cannot resize an open LUKS2 volume: it logs
# "crypt_resize() ... Operation not permitted" at every start. The partition
# fills the disk already.
GROWFS_ROOT_MASK = "etc/systemd/system/systemd-growfs-root.service"
CHROOT_ENV = {
    "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
    "LANG": "C.UTF-8",
    "HOME": "/root",
    "TERM": os.environ.get("TERM", "linux"),
}

# Layouts without Latin letters (D-78). As Debian does for them, the new
# system gets the US layout first and this one second, with Alt+Shift to
# switch, so user names and passwords can be typed in Latin letters. The list
# is the one of keyboard-configuration.config in console-setup 1.242~deb13u1;
# names that the XKB rules no longer have never match.
NON_LATIN_LAYOUTS = {
    "af", "am", "ara", "ben", "bd", "bg", "bt", "by", "et", "ge", "gh", "gr",
    "guj", "guru", "il", "in", "iq", "ir", "iku", "kan", "kh", "kz", "la", "lao",
    "lk", "kg", "ma", "mk", "mm", "mn", "mv", "mal", "np", "ori", "pk", "ru",
    "scc", "sy", "syr", "tel", "th", "tj", "tam", "tib", "ua", "ug", "uz",
}
# The XKB options Debian sets for two layouts: Alt+Shift switches them, and
# the Scroll Lock light is on with the second one.
SWITCH_OPTIONS = "grp:alt_shift_toggle,grp_led:scroll"

SWAP_CHOICES = [
    ("zram", "zram: compressed swap in RAM, fast and without writes to the disk (recommended)"),
    ("file", "swap file on the disk"),
    ("both", "both: zram first, then the swap file"),
    ("none", "no swap"),
]

# Texts that both installers show.
ENCRYPTION_TEXT = (
    "Encryption protects your files when the computer is lost or stolen: "
    "without the passphrase nobody can read the disk. The computer then asks "
    "for the passphrase at every start. Encryption cannot be added later "
    "without installing Legion again.")
PASSPHRASE_TEXT = (
    "At every start the computer asks for this passphrase before Legion "
    "starts. Use at least 8 characters; a few unrelated words are easy to "
    "remember and hard to guess. You will also get a recovery key in case "
    "you forget it.")
SECURITY_KEY_TEXT = (
    "A FIDO2 security key is connected. It can unlock the disk instead of "
    "the passphrase: you plug it in and touch it at start. The passphrase "
    "and the recovery key keep working.")
RECOVERY_KEY_TEXT = (
    "If you forget the disk passphrase, this key unlocks the disk instead. "
    "Write it down now and keep it in a safe place, away from this computer. "
    "It has only the letters c b d e f g h i j k l n r t u v. Take a photo of "
    "the screen, or write it in capital letters, so that u and n do not get "
    "mixed up.")
TWO_LAYOUTS_TEXT = (
    "This layout has no Latin letters, so Legion puts the US layout before "
    "it, as Debian does. Alt+Shift switches between the two. Type user names "
    "and passwords in the US layout: the computer starts with it.")

log_file = None
lock_file = None
cleanup_steps = []
disk_changed = False


class InstallError(Exception):
    pass


class Cancelled(Exception):
    pass


class Frontend:
    """What install() needs from a user interface. The text installer calls
    these methods from its only thread, the window from the thread that runs
    install()."""

    def step(self, text):
        """A step of the installation starts."""

    def running(self, time):
        """A long step still runs, after this time; about once a second."""

    def note(self, text):
        """A result of the current step, for example its time."""

    def keep_damaged_copy(self, lines):
        """dpkg --verify found package files that differ from their packages
        (its lines). Returns True to go on anyway."""
        return False

    def check_recovery_key(self, key):
        """Shows the recovery key and returns when the user has typed the
        groups of recovery_key_checks() from the note of it (D-75)."""
        raise NotImplementedError

    def add_security_key(self, enroll):
        """Lets the user add a FIDO2 security key. enroll(ask_pin) adds it
        (see enroll_security_key) and returns False when that failed.
        Returns whether the key was added."""
        raise NotImplementedError


# Log and commands


def log(message):
    if log_file:
        log_file.write(f"{time.strftime('%H:%M:%S')} {message}\n")
        log_file.flush()


def log_tail(lines=15):
    try:
        return LOG_FILE.read_text(errors="replace").splitlines()[-lines:]
    except OSError:
        return []


def run(args, *, chroot=False, input=None, env=None, capture=False, check=True,
        interactive=False, hide_stderr=False):
    """Runs a command. Its output goes to the log, or with capture=True its
    standard output is returned. Secrets go only through input and env, which
    are never logged."""
    args = [str(a) for a in args]
    if chroot:
        args = ["chroot", str(TARGET), *args]
        env = {**CHROOT_ENV, **(env or {})}
    elif env:
        env = {**os.environ, **env}
    log("$ " + shlex.join(args))
    if interactive:
        result = subprocess.run(args, env=env)
        output = ""
    else:
        stderr = subprocess.DEVNULL if hide_stderr else (log_file or subprocess.DEVNULL)
        result = subprocess.run(
            args, env=env, text=True,
            input=input, stdin=None if input is not None else subprocess.DEVNULL,
            stdout=subprocess.PIPE if capture else (log_file or subprocess.DEVNULL),
            stderr=stderr if capture else subprocess.STDOUT,
        )
        output = result.stdout if capture else ""
    if result.returncode != 0:
        log(f"exit status {result.returncode}")
        if check:
            raise InstallError(f"{shlex.join(args[:4])} failed (exit status {result.returncode}).")
    return output if capture else result.returncode


def run_long(args, title, ui, *, chroot=False):
    """Runs a long command and tells the user interface how long it runs."""
    args = [str(a) for a in args]
    env = None
    if chroot:
        args = ["chroot", str(TARGET), *args]
        env = CHROOT_ENV
    ui.step(title)
    log("$ " + shlex.join(args))
    start = time.monotonic()
    with subprocess.Popen(args, env=env, stdin=subprocess.DEVNULL,
                          stdout=log_file, stderr=subprocess.STDOUT) as process:
        while True:
            try:
                code = process.wait(timeout=1)
                break
            except subprocess.TimeoutExpired:
                ui.running(elapsed(start))
    log(f"exit status {code} after {elapsed(start)}")
    if code != 0:
        raise InstallError(f"{shlex.join(args[:4])} failed (exit status {code}).")
    ui.note(f"done in {elapsed(start)}")


def run_answering_passwords(args, ask):
    """Runs a command without a terminal and answers its password questions
    as a password agent (https://systemd.io/PASSWORD_AGENTS/): the command
    writes a question to /run/systemd/ask-password/ and waits for the answer
    on a socket. ask(message, again) returns the answer, or None to cancel
    the question; again is True from the second question on, for example
    after a wrong PIN. Only questions of this command are answered. Returns
    the exit status."""
    args = [str(a) for a in args]
    log("$ " + shlex.join(args))
    answered = set()
    with subprocess.Popen(args, stdin=subprocess.DEVNULL,
                          stdout=log_file or subprocess.DEVNULL, stderr=subprocess.STDOUT) as process:
        while process.poll() is None:
            for path, question in password_questions(process.pid):
                if path not in answered:
                    answered.add(path)
                    send_password(question["Socket"], ask(question.get("Message", ""), len(answered) > 1))
            time.sleep(0.2)
    log(f"exit status {process.returncode}")
    return process.returncode


def password_questions(pid):
    """Password questions of the process pid that wait for an agent."""
    questions = []
    for path in sorted(ASK_PASSWORD.glob("ask.*")):
        question = read_assignments(path)
        if question.get("PID") == str(pid) and question.get("Socket"):
            questions.append((path, question))
    return questions


def send_password(socket_path, password):
    """Answers a password question on its socket; None cancels it."""
    packet = b"-" if password is None else b"+" + password.encode()
    with socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM) as sock:
        try:
            sock.sendto(packet, socket_path)
        except OSError as error:  # the question is gone
            log(f"password agent: {error}")


def elapsed(start):
    seconds = int(time.monotonic() - start)
    return f"{seconds // 60} min {seconds % 60:02d} s" if seconds >= 60 else f"{seconds} s"


# Facts about the live system


def read_assignments(path):
    """KEY=value lines, as in /etc/default/keyboard and /etc/locale.conf."""
    values = {}
    try:
        for line in Path(path).read_text().splitlines():
            key, sep, value = line.partition("=")
            if sep and not key.strip().startswith("#"):
                values[key.strip()] = value.strip().strip('"')
    except OSError:
        pass
    return values


def load_locales():
    """UTF-8 locales from the list of glibc, for example pl_PL.UTF-8."""
    locales = {}
    for line in Path("/usr/share/i18n/SUPPORTED").read_text().splitlines():
        parts = line.split()
        if len(parts) == 2 and parts[1] == "UTF-8":
            locales[parts[0]] = line.strip()
    return locales


def language_name(locale):
    """The name of a locale from its definition in glibc, for example
    "Polish (Poland)" for pl_PL.UTF-8, or "" when it has none."""
    base, _, modifier = locale.partition("@")
    path = Path("/usr/share/i18n/locales") / (base.split(".")[0] + (f"@{modifier}" if modifier else ""))
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    section = re.search(r"^LC_IDENTIFICATION$(.*?)^END LC_IDENTIFICATION", text, re.M | re.S)
    if not section:
        return ""
    names = {}
    for key in ("language", "territory"):
        found = re.search(rf'^{key}\s+"([^"]*)"', section.group(1), re.M)
        names[key] = found.group(1) if found else ""
    details = ", ".join(filter(None, [names["territory"], modifier]))
    return f"{names['language']} ({details})" if names["language"] and details else names["language"]


def load_keyboard_layouts():
    """Layouts and their variants from the XKB rules."""
    layouts, variants = {}, {}
    section = None
    for line in Path("/usr/share/X11/xkb/rules/base.lst").read_text(encoding="utf-8").splitlines():
        if line.startswith("! "):
            section = line[2:].strip()
            continue
        name, _, description = line.strip().partition(" ")
        if not name:
            continue
        description = description.strip()
        if section == "layout":
            layouts[name] = description
        elif section == "variant":
            layout, _, text = description.partition(":")
            variants.setdefault(layout.strip(), {})[name] = text.strip()
    return layouts, variants


def load_timezones(links=True):
    """Time zone names as systemd lists them, from tzdata.zi. Without links,
    only the zones themselves, without old names such as Europe/Kiev."""
    names = {"UTC"}
    for line in Path("/usr/share/zoneinfo/tzdata.zi").read_text().splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[0] == "Z":
            names.add(parts[1])
        elif links and len(parts) >= 3 and parts[0] == "L":
            names.add(parts[2])
    return sorted(names)


def current_timezone():
    try:
        return os.readlink("/etc/localtime").split("zoneinfo/", 1)[1]
    except (OSError, IndexError):
        return "UTC"


def existing_names():
    names = set()
    for path in ("/etc/passwd", "/etc/group"):
        for line in Path(path).read_text().splitlines():
            names.add(line.split(":", 1)[0])
    return names


def block_devices(*devices):
    output = run(["lsblk", "--json", "--bytes", "--output",
                  "NAME,PATH,TYPE,SIZE,RO,TRAN,MODEL,PARTTYPE,FSTYPE,MOUNTPOINTS", *devices],
                 capture=True)
    return json.loads(output)["blockdevices"]


def walk(device):
    yield device
    for child in device.get("children") or []:
        yield from walk(child)


def in_use(disk):
    """Mounted parts of a disk, and devices built on it, such as an open
    encrypted volume."""
    return [d["path"] for d in walk(disk)
            if any(d.get("mountpoints") or []) or d["type"] not in ("disk", "part")]


def parent_disk(partition):
    name = run(["lsblk", "--nodeps", "--noheadings", "--output", "PKNAME", partition],
               capture=True).strip()
    return f"/dev/{name}" if name else None


def disk_id(path):
    """A stable name from /dev/disk/by-id/, as D-59 asks for."""
    by_id = Path("/dev/disk/by-id")
    names = sorted(p.name for p in by_id.iterdir() if os.path.realpath(p) == path) if by_id.is_dir() else []
    for prefix in ("nvme-", "ata-", "usb-", "mmc-", "scsi-", "virtio-"):
        for name in names:
            if name.startswith(prefix) and not name.startswith("nvme-eui."):
                return name
    return names[0] if names else None


def disk_size(disk):
    return f"{disk['size'] / 1024**3:.1f} GiB"


def disk_model(disk):
    return (disk.get("model") or "").strip() or "unknown model"


def disk_contents(disk):
    """File systems and other contents found on the disk, such as ext4 or crypto_LUKS."""
    return sorted({d.get("fstype") for d in walk(disk) if d is not disk and d.get("fstype")})


def describe_disk(disk):
    transport = (disk.get("tran") or "").upper()
    contents = disk_contents(disk)
    text = f"{disk['path']}  {disk_size(disk)}  {disk_model(disk)}{f'  ({transport})' if transport else ''}"
    text += f"\n       now: {', '.join(contents)}" if contents else "\n       now: no partitions found"
    return text


def fido2_devices():
    output = run(["systemd-cryptenroll", "--fido2-device=list"], capture=True, check=False)
    return [line.split()[0] for line in output.splitlines() if line.startswith("/dev/")]


# Checks before the questions


def check_environment():
    """Raises InstallError when Legion cannot be installed from this system.
    Both installers check first that they run as root."""
    if "legion.live" not in Path("/proc/cmdline").read_text().split():
        raise InstallError(
            "The installer works only in the live session: start Legion from the "
            "USB stick with the default entry of the boot menu (RAM mode) or with "
            "Low memory mode.")
    if not Path("/sys/firmware/efi/efivars").is_dir():
        raise InstallError(
            "This computer did not start in UEFI mode. Legion needs UEFI: turn off "
            "the legacy (CSM) mode in the firmware settings and start again.")


def lock():
    """Makes sure that only one installer runs: a second one would close the
    disk volume of the first (remove_leftovers) or install on the same disk.
    The lock lasts until the program ends."""
    global lock_file
    lock_file = open(LOCK_FILE, "a")
    try:
        fcntl.flock(lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise InstallError("Another Legion installer is running. Close it first, or wait until it ends.")


def remove_leftovers():
    """Closes the disk volume of an earlier, interrupted run."""
    if TARGET_DEVICE.exists():
        run(["systemd-cryptsetup", "detach", TARGET_VOLUME], check=False)


def find_boot_partition():
    """The root partition of the Legion USB stick, or None when it is not
    connected. The installer copies the system from it."""
    return os.path.realpath(BOOT_PARTITION) if BOOT_PARTITION.exists() else None


def candidate_disks(boot_disk):
    """Disks Legion can be installed on and disks that are too small for it,
    without the USB stick it started from."""
    disks = [d for d in block_devices()
             if d["type"] == "disk" and not d["ro"] and d["path"] != boot_disk
             and not d["name"].startswith(("zram", "ram"))]
    return ([d for d in disks if d["size"] >= MIN_DISK_SIZE],
            [d for d in disks if d["size"] < MIN_DISK_SIZE])


# Checks of the answers: they return the value to use or raise ValueError with
# a message for the user.


def check_hostname(answer):
    if re.fullmatch(r"[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?", answer):
        return answer
    raise ValueError("Use 1 to 63 lowercase letters, digits and hyphens, without a hyphen at the ends.")


def check_full_name(answer):
    if any(c in answer for c in ":,=\n"):
        raise ValueError("Do not use the characters : , and =.")
    return answer


def check_user_name(answer, taken):
    if not re.fullmatch(r"[a-z][a-z0-9_-]{0,31}", answer):
        raise ValueError("Start with a lowercase letter, then use lowercase letters, digits, - and _ (at most 32).")
    if answer in taken:
        raise ValueError(f"The name {answer} is already used by the system. Choose another one.")
    return answer


def suggested_user_name(full_name, taken):
    """The first name in lowercase, if it makes a valid user name."""
    words = full_name.split()
    try:
        return check_user_name(words[0].lower(), taken) if words else None
    except ValueError:
        return None


def check_password(answer):
    if not answer:
        raise ValueError("The password cannot be empty.")
    return answer


def check_disk_passphrase(answer):
    if len(answer) < 8:
        raise ValueError("Use at least 8 characters.")
    return answer


def swap_file_limit(disk_size):
    """The largest swap file in GiB: a quarter of the disk, from 1 to 32."""
    return max(1, min(32, disk_size // 1024**3 // 4))


def keyboard_settings(layout, variant):
    """XKBLAYOUT, XKBVARIANT and XKBOPTIONS of the new system for the chosen
    layout and variant (D-78)."""
    if layout in NON_LATIN_LAYOUTS:
        return f"us,{layout}", f",{variant}", SWITCH_OPTIONS
    return layout, variant, ""


def session_keyboard():
    """XKBLAYOUT, XKBVARIANT and XKBOPTIONS of the live session."""
    keyboard = read_assignments("/etc/default/keyboard")
    return (keyboard.get("XKBLAYOUT", "") or "us", keyboard.get("XKBVARIANT", ""),
            keyboard.get("XKBOPTIONS", ""))


def set_session_keyboard(layout, variant="", options=""):
    """Switches the keyboard of the live session (D-73) to XKB settings,
    comma-separated as in /etc/default/keyboard. sudo and pkexec keep DISPLAY
    and XAUTHORITY, so setxkbmap reaches the desktop. Without a variant,
    setxkbmap also clears the variant set before, and the empty -option
    clears the options set before."""
    if not os.environ.get("DISPLAY") or not shutil.which("setxkbmap"):
        return False
    args = ["setxkbmap", "-layout", layout]
    if variant.strip(","):
        args += ["-variant", variant]
    args += ["-option", ""]
    for option in filter(None, options.split(",")):
        args += ["-option", option]
    return run(args, check=False, hide_stderr=True) == 0


def recovery_key_checks(key):
    """Numbers of the groups of the recovery key to type from the note,
    chosen at random (D-75)."""
    count = len(key.split("-"))
    return sorted(secrets.SystemRandom().sample(range(1, count + 1), RECOVERY_KEY_CHECKS))


def recovery_group_matches(key, number, answer):
    """Whether the answer is that group of the key, in any case and with or
    without spaces."""
    return answer.replace(" ", "").lower() == key.split("-")[number - 1]


def summary(answers, layouts):
    """The answers other than the disk, as (title, text) for the summary."""
    layout, variant = answers["keyboard"]
    full_name, user, _ = answers["account"]
    swap, size = answers["swap"]
    keyboard = f"{layout} ({layouts[layout]}){f', variant {variant}' if variant else ''}"
    if layout in NON_LATIN_LAYOUTS:
        keyboard += ", after us (Alt+Shift switches)"
    if answers["encrypt"]:
        keys = ["passphrase", "recovery key"] + (["security key"] if answers["fido2"] else [])
        encryption = f"yes ({', '.join(keys)})"
    else:
        encryption = "no"
    return [
        ("Language", answers["language"]),
        ("Keyboard", keyboard),
        ("Time zone", answers["timezone"]),
        ("Computer name", answers["hostname"]),
        ("Account", f"{user}{f' ({full_name})' if full_name else ''}, administrator"),
        ("Encryption", encryption),
        ("Swap", f"{swap}{f', swap file {size} GiB' if size else ''}"),
    ]


def next_steps(answers, result):
    """What to do after the installation, as paragraphs."""
    user = answers["account"][1]
    steps = ["Restart the computer and remove the USB stick when the screen goes dark."]
    if answers["encrypt"]:
        steps.append(f"At start, type the disk passphrase, then log in as {user}. "
                     "The recovery key works instead of the passphrase: type it in small "
                     "letters, with the dashes.")
        if not result["security_key"]:
            steps.append("To add a FIDO2 security key later, run in the new system:\n"
                         f"    sudo systemd-cryptenroll --fido2-device=auto {result['root']}")
    else:
        steps.append(f"Then log in as {user}.")
    return steps


# Installation steps


def start_log():
    global log_file
    WORK.mkdir(mode=0o700, exist_ok=True)
    os.chmod(WORK, 0o700)
    log_file = open(LOG_FILE, "a")
    os.chmod(LOG_FILE, 0o600)
    log(f"legion-install {VERSION}")


def private_mounts():
    """Mounts made from now on stay in this thread and its child processes:
    unshare() gives a new mount namespace only to the calling thread."""
    os.unshare(os.CLONE_NEWNS)
    run(["mount", "--make-rprivate", "/"])


def mount_source(boot_partition, boot_disk):
    if os.path.ismount(OVERLAY_LOWER):
        source = OVERLAY_LOWER
        log(f"source: read-only layer of overlay mode, {OVERLAY_LOWER}")
    else:
        SOURCE.mkdir(exist_ok=True)
        run(["mount", "-o", "ro", boot_partition, SOURCE])
        source = SOURCE
    esp = [d["path"] for d in walk(block_devices(boot_disk)[0]) if d.get("parttype") == ESP_TYPE]
    if len(esp) != 1:
        raise InstallError(f"The EFI system partition of the USB stick ({boot_disk}) was not found.")
    SOURCE_ESP.mkdir(exist_ok=True)
    run(["mount", "-o", "ro", esp[0], SOURCE_ESP])
    # The kernel package puts vmlinuz, config and System.map in /boot, which
    # is the EFI system partition in the image. They go to /boot on the
    # root partition of the new system.
    kernels = sorted(p.name for p in (source / "usr/lib/modules").iterdir()
                     if (SOURCE_ESP / f"vmlinuz-{p.name}").is_file())
    if not kernels:
        raise InstallError("No kernel was found on the USB stick.")
    log(f"kernels: {' '.join(kernels)}")
    return source, kernels


def partition_and_copy(disk, source, encrypt, ui):
    global disk_changed
    args = ["systemd-repart", "--dry-run=no", "--empty=force", "--offline=no",
            "--seed=random", "--no-pager", "--pretty=no", f"--definitions={DEFINITIONS}"]
    if encrypt:
        # A temporary key, replaced by your passphrase at the end.
        KEY_FILE.unlink(missing_ok=True)
        old_umask = os.umask(0o077)
        try:
            KEY_FILE.write_text(secrets.token_hex(32))
        finally:
            os.umask(old_umask)
        args += [f"--definitions={ENCRYPTION_DEFINITIONS}", f"--key-file={KEY_FILE}"]
    disk_changed = True
    run_long(args + [f"--copy-source={source}", disk],
             "Partitioning the disk and copying Legion (several minutes)", ui)
    run(["udevadm", "settle"])
    partitions = [d for d in walk(block_devices(disk)[0]) if d["type"] == "part"]
    esp = [d["path"] for d in partitions if d.get("parttype") == ESP_TYPE]
    root = [d["path"] for d in partitions if d.get("parttype") == ROOT_TYPE]
    if len(esp) != 1 or len(root) != 1:
        raise InstallError(f"The new partitions on {disk} were not found.")
    return esp[0], root[0]


def mount_target(esp, root, encrypt):
    device = root
    if encrypt:
        run(["systemd-cryptsetup", "attach", TARGET_VOLUME, root, KEY_FILE, "luks"])
        cleanup_steps.append(lambda: run(["systemd-cryptsetup", "detach", TARGET_VOLUME], check=False))
        device = TARGET_DEVICE
    TARGET.mkdir(exist_ok=True)
    run(["mount", device, TARGET])
    cleanup_steps.append(lambda: run(["umount", "--recursive", TARGET], check=False))
    (TARGET / "efi").mkdir(exist_ok=True)
    run(["mount", esp, TARGET / "efi"])
    # What programs in the new system need: kernel interfaces, devices (with
    # the EFI variables under /sys) and the udev database.
    run(["mount", "-t", "proc", "proc", TARGET / "proc"])
    for path in ("sys", "dev"):
        run(["mount", "--rbind", f"/{path}", TARGET / path])
        run(["mount", "--make-rslave", TARGET / path])
    run(["mount", "-t", "tmpfs", "-o", "mode=0755,nosuid,nodev", "tmpfs", TARGET / "run"])
    (TARGET / "run/udev").mkdir()
    run(["mount", "--bind", "/run/udev", TARGET / "run/udev"])


def write_target_file(relative, text, mode=0o644):
    path = TARGET / relative
    if path.is_symlink():
        path.unlink()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    os.chmod(path, mode)
    log(f"wrote /{relative}")


def copy_kernels(kernels):
    for version in kernels:
        for stem in ("vmlinuz", "config", "System.map"):
            source = SOURCE_ESP / f"{stem}-{version}"
            if source.is_file():
                target = TARGET / "boot" / source.name
                shutil.copyfile(source, target)
                os.chmod(target, 0o644)
                log(f"copied /boot/{source.name}")


def configure(answers, ui):
    write_target_file("etc/hostname", answers["hostname"] + "\n")

    locales = load_locales()
    language = answers["language"]
    generate = [locales["en_US.UTF-8"]] + ([locales[language]] if language != "en_US.UTF-8" else [])
    write_target_file("etc/locale.gen", "".join(f"{line}\n" for line in generate))
    write_target_file("etc/locale.conf", f"LANG={language}\n")
    run(["locale-gen"], chroot=True)

    layout, variant, options = keyboard_settings(*answers["keyboard"])
    write_target_file("etc/default/keyboard",
                      "# Keyboard layout of the console and of the desktop, see keyboard(5).\n"
                      'XKBMODEL="pc105"\n'
                      f'XKBLAYOUT="{layout}"\n'
                      f'XKBVARIANT="{variant}"\n'
                      f'XKBOPTIONS="{options}"\n'
                      'BACKSPACE="guess"\n')
    # The console and the disk passphrase prompt of the initrd use the keymap
    # that console-setup derives from this file (dracut module console-setup,
    # loaded by legion-console-setup from legion-boot).
    if run(["setupcon", "--save-only"], chroot=True, check=False) != 0:
        ui.note("Warning: could not prepare the console keymap; see the log.")

    localtime = TARGET / "etc/localtime"
    localtime.unlink(missing_ok=True)
    localtime.symlink_to(f"../usr/share/zoneinfo/{answers['timezone']}")
    log(f"time zone {answers['timezone']}")

    full_name, user, password = answers["account"]
    run(["useradd", "--create-home", "--comment", full_name,
         "--groups", ",".join(ACCOUNT_GROUPS), "--shell", "/bin/bash", user], chroot=True)
    run(["chpasswd"], chroot=True, input=f"{user}:{password}\n")
    run(["passwd", "--lock", "root"], chroot=True)

    swap, size = answers["swap"]
    if swap in ("zram", "both"):
        mask = TARGET / ZRAM_MASK
        if mask.is_symlink() and os.readlink(mask) == "/dev/null":
            mask.unlink()
            log(f"removed /{ZRAM_MASK}, zram is on")
    if swap in ("file", "both"):
        run(["mkswap", "--file", "--size", f"{size}G", "/swapfile"], chroot=True)
        fstab = TARGET / "etc/fstab"
        text = fstab.read_text() if fstab.is_file() else ""
        text += "# Swap file from the Legion installer (D-48, D-59).\n/swapfile none swap defaults 0 0\n"
        write_target_file("etc/fstab", text)

    if answers["encrypt"]:
        mask = TARGET / GROWFS_ROOT_MASK
        mask.unlink(missing_ok=True)
        mask.parent.mkdir(parents=True, exist_ok=True)
        mask.symlink_to("/dev/null")
        log(f"masked /{GROWFS_ROOT_MASK}")

    installed = [p for p in LIVE_PACKAGES
                 if run(["dpkg-query", "--show", "--showformat=${Status}", p],
                        chroot=True, capture=True, check=False).endswith(" installed")]
    if installed:
        run(["dpkg", "--purge", *installed], chroot=True)


def install_boot_loader(kernels, ui):
    # bootctl writes the boot entry "Linux Boot Manager" into the firmware
    # (EFI variables). It does that only without --root, hence the chroot.
    run(["bootctl", "install", "--esp-path=/efi"], chroot=True)
    for version in kernels:
        run_long(["kernel-install", "add", version, f"/boot/vmlinuz-{version}"],
                 f"Building the initrd and the boot menu entry of kernel {version}", ui, chroot=True)
    entries = sorted(p.name for p in (TARGET / "efi/loader/entries").glob("*.conf"))
    if not entries:
        raise InstallError("kernel-install did not create a boot menu entry.")
    log(f"boot menu entries: {' '.join(entries)}")


def drop_page_cache():
    """Makes the next reads come from the disk, not from memory."""
    run(["sync"])
    Path("/proc/sys/vm/drop_caches").write_text("3\n")


def verify_copy():
    """Package files of the new system that differ from their packages, as
    lines of dpkg --verify."""
    drop_page_cache()
    output = run(["dpkg", f"--root={TARGET}", "--verify"], capture=True, check=False)
    # Lines of package files, as in legion-test: changed configuration files
    # (flag c) are left out, and so is os-release, which mkosi changes.
    failed = [line for line in output.splitlines()
              if re.match(r"^(missing|[?.\w]{9}) +/", line)
              and not line.rstrip().endswith(" /usr/lib/os-release")]
    log(f"dpkg --verify: {len(failed)} files")
    for line in failed:
        log(f"  {line}")
    return failed


def key_slots(root):
    """Slots of the LUKS2 header as listed by systemd-cryptenroll."""
    output = run(["systemd-cryptenroll", root], capture=True)
    rows = [line.split() for line in output.splitlines()]
    return [row[:2] for row in rows if len(row) >= 2 and row[0].isdigit()]


def enroll_security_key(root, ask_pin=None):
    """Adds a FIDO2 security key to the encrypted partition. The user touches
    the key when it blinks, maybe twice. Without ask_pin, systemd-cryptenroll
    asks for the PIN of the key in the terminal. The window has no terminal,
    so it passes ask_pin(message, again) and the installer answers as a
    password agent. A PIN file (credential) is not used: with a wrong PIN,
    systemd-cryptenroll 257 would try it again and again until the key
    blocks its PIN. Returns whether the key was added."""
    args = ["systemd-cryptenroll", f"--unlock-key-file={KEY_FILE}", "--fido2-device=auto", root]
    if ask_pin is None:
        return run(args, interactive=True, check=False) == 0
    return run_answering_passwords(args, ask_pin) == 0


def set_up_unlocking(root, passphrase, use_fido2, ui):
    """Replaces the temporary key of systemd-repart with a recovery key, the
    passphrase and optionally a FIDO2 security key. Returns whether a
    security key was added."""
    ui.step("Adding a recovery key")
    recovery = run(["systemd-cryptenroll", f"--unlock-key-file={KEY_FILE}", "--recovery-key", root],
                   capture=True, hide_stderr=True).strip()
    log("recovery key enrolled")
    ui.check_recovery_key(recovery)

    security_key = False
    if use_fido2:
        ui.step("Adding the security key")
        security_key = ui.add_security_key(lambda ask_pin=None: enroll_security_key(root, ask_pin))
        log("FIDO2 key enrolled" if security_key else "FIDO2 key skipped")

    # The temporary key of systemd-repart is in slot 0, the only slot without
    # a token so far. The passphrase replaces it.
    ui.step("Setting the disk passphrase")
    slots = key_slots(root)
    if ["0", "password"] not in slots or sum(1 for s in slots if s[1] == "password") != 1:
        raise InstallError(f"Unexpected key slots on {root}: {slots}")
    run(["systemd-cryptenroll", f"--unlock-key-file={KEY_FILE}", "--password", "--wipe-slot=0", root],
        env={"NEWPASSWORD": passphrase})
    slots = key_slots(root)
    log(f"key slots: {slots}")
    if any(s[0] == "0" for s in slots) or not any(s[1] == "password" for s in slots):
        raise InstallError(f"The disk passphrase was not set as expected: {slots}")
    KEY_FILE.unlink(missing_ok=True)
    return security_key


def save_log():
    if (TARGET / "var/log").is_dir():
        try:
            shutil.copyfile(LOG_FILE, TARGET / "var/log/legion-install.log")
            os.chmod(TARGET / "var/log/legion-install.log", 0o600)
        except OSError as error:
            log(f"could not copy the log: {error}")


def cleanup():
    while cleanup_steps:
        step = cleanup_steps.pop()
        try:
            step()
        except Exception as error:  # cleanup must go on
            log(f"cleanup: {error}")
    for path in (SOURCE_ESP, SOURCE):
        if os.path.ismount(path):
            run(["umount", path], check=False)
    KEY_FILE.unlink(missing_ok=True)


def install(answers, ui):
    """Installs Legion with the answers: disk (from candidate_disks), language,
    keyboard (layout, variant), timezone, hostname, account (full name, user
    name, password), encrypt, passphrase, fido2 and swap (choice, size in
    GiB). ui is a Frontend. Raises InstallError when the installation fails;
    disk_changed then tells whether the disk was erased already. Returns the
    root partition, the time the installation took and whether a security
    key was added."""
    disk = answers["disk"]["path"]
    layout, variant = answers["keyboard"]
    _, user, _ = answers["account"]
    swap, size = answers["swap"]
    start_log()
    log(f"disk {disk} ({disk_id(disk)}), language {answers['language']}, "
        f"keyboard {layout}:{variant}, time zone {answers['timezone']}, hostname {answers['hostname']}, "
        f"user {user}, swap {swap} {size}, encryption {answers['encrypt']}, fido2 {answers['fido2']}")
    try:
        boot_partition = find_boot_partition()
        if not boot_partition:
            raise InstallError("The Legion USB stick is not connected. Plug it in and run the installer again.")
        boot_disk = parent_disk(boot_partition)
        if disk == boot_disk:
            raise InstallError(f"{disk} is the Legion USB stick.")
        busy = in_use(block_devices(disk)[0])
        if busy:
            raise InstallError(f"Parts of {disk} are in use: {', '.join(busy)}. Unmount them, "
                               "or restart the live session, and run the installer again.")
        private_mounts()

        started = time.monotonic()
        ui.step("Reading Legion from the USB stick")
        source, kernels = mount_source(boot_partition, boot_disk)
        esp, root = partition_and_copy(disk, source, answers["encrypt"], ui)
        mount_target(esp, root, answers["encrypt"])
        copy_kernels(kernels)
        ui.step("Setting up the new system")
        configure(answers, ui)
        ui.step("Installing the boot loader")
        install_boot_loader(kernels, ui)
        ui.step("Checking the copied files (dpkg --verify)")
        failed = verify_copy()
        if not failed:
            ui.note("all package files are correct")
        elif not ui.keep_damaged_copy(failed):
            raise InstallError("The installation was stopped after dpkg --verify.")
        security_key = False
        if answers["encrypt"]:
            security_key = set_up_unlocking(root, answers["passphrase"], answers["fido2"], ui)
        took = elapsed(started)
        log(f"installation finished after {took}")
        save_log()
        return {"root": root, "time": took, "security_key": security_key}
    finally:
        cleanup()
        log("end")
