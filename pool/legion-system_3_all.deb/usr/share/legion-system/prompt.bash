# The LegionOS prompt in terminal windows (D-83), read at the end of
# ~/.bashrc of new accounts:
#
#   ┌──(<emblem> user)─[🗁 ~/folder]──(venv)
#   └─➢
#
# The emblem is the character U+E500 of the font Legion Symbols (package
# legion-artwork), in the green of the Legion logo. Over SSH, or without that
# font, user@host takes its place. The text console and other terminals
# without colors keep the prompt of Debian.
#
# To go back to the prompt of Debian, delete the lines that read this file at
# the end of ~/.bashrc. To change the prompt, put a copy of this file in their
# place and edit it there.

case "${TERM:-}" in
    xterm-color|*-256color) ;;
    *) return ;;
esac

# Python virtual environments show in the frame instead of before it.
export VIRTUAL_ENV_DISABLE_PROMPT=1

if [ -z "${SSH_CONNECTION:-}" ] && [ -e /usr/share/fonts/truetype/legion/LegionSymbols-Regular.ttf ]; then
    legion_emblem=$(printf '\356\224\200')  # U+E500 in UTF-8
    legion_name='\[\e[0;38;2;104;244;68m\]'"$legion_emblem"'\[\e[1;32m\] \u'
else
    legion_name='\[\e[1;32m\]\u@\h'
fi

# The folder 🗁 is wider than its cell, so two spaces follow it.
PS1='\[\e[0;34m\]┌──${debian_chroot:+($debian_chroot)──}('"$legion_name"'\[\e[0;34m\])─[\[\e[0;33m\]🗁  \[\e[4;37m\]\w\[\e[0;34m\]]${VIRTUAL_ENV:+──(\[\e[1;35m\]${VIRTUAL_ENV##*/}\[\e[0;34m\])}\n\[\e[0;34m\]└─\[\e[0;32m\]➢\[\e[0m\] '

# The window title, as in the prompt of Debian.
case "$TERM" in
    xterm*|rxvt*)
        PS1='\[\e]0;${debian_chroot:+($debian_chroot)}\u@\h: \w\a\]'"$PS1"
        ;;
esac

unset legion_emblem legion_name
