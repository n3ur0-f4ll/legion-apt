# legion_install: the Legion installer without its user interface (D-59, D-69
# to D-81). The text installer legion-install and the window
# legion-install-gui ask the questions and show the progress; this module
# knows the computer, checks the answers and installs Legion with install().
# It erases the whole disk you choose or, on a disk with Legion and its own
# partitions for /home, /srv or other folders, installs Legion again and
# keeps those partitions (D-79, D-80):
#
#   1. systemd-repart creates the partitions of the layout you choose, from
#      definitions it writes to /run/legion-install/repart.d/: an EFI system
#      partition of 1 GiB and the root partition on the rest of the disk or,
#      for example, the root partition and /home (D-81). They get ext4 (or
#      swap) and, if you choose it, LUKS2 encryption (D-72). systemd-repart
#      copies the root partition of the USB stick into them: every partition
#      gets the folder it is mounted on. A reinstallation (its factory reset)
#      creates the EFI system partition, /, /var, /var/tmp and swap again and
#      leaves the others as they are;
#   2. the new system gets its language, keyboard layout, time zone, computer
#      name, account and swap, and loses the packages of the live session;
#   3. bootctl and kernel-install, run inside the new system, install
#      systemd-boot and a boot menu entry with an initrd built by dracut (D-57);
#   4. dpkg --verify checks the copied package files (D-56, D-59);
#   5. on an encrypted disk, systemd-cryptenroll replaces the temporary key
#      with your passphrase and a recovery key, and optionally adds a FIDO2
#      security key. The other partitions get keys in /etc/cryptsetup-keys.d/
#      on the encrypted root partition, so the computer asks once at start.
#
# The new system finds /, /efi, /home, /srv, /var, /var/tmp and swap by
# their partition types (systemd-gpt-auto-generator, Discoverable Partitions
# Specification), without /etc/fstab. It mounts /var only when the UUID of
# the partition comes from /etc/machine-id: the installer gives systemd-repart
# the machine ID of the new system as --seed, which derives that UUID. Other
# folders get lines in /etc/fstab and, when encrypted, /etc/crypttab.
#
# The root partition of the USB stick is only read: in RAM mode the installer
# mounts it read-only, in overlay mode it uses the read-only layer of the
# running system. Changes made in the live session, for example the live
# account or saved Wi-Fi passwords, do not reach the new system.
#
# All mounts happen in a private mount namespace of the thread that runs
# install(), so the desktop does not see them and they disappear when the
# installer ends. A log without passwords and keys is kept in
# /run/legion-install/install.log and copied to /var/log/legion-install.log on
# the new system. While install() runs, a lock of logind keeps the computer
# awake, also when the lid of a laptop is closed (keep_awake).

import fcntl
import json
import math
import os
import re
import secrets
import shlex
import shutil
import socket
import stat
import subprocess
import time
import uuid
from pathlib import Path

VERSION = "8"

WORK = Path("/run/legion-install")
DEFINITIONS = WORK / "repart.d"
SOURCE = WORK / "source"
SOURCE_ESP = WORK / "source-esp"
TARGET = WORK / "target"
# The temporary key of new encrypted partitions, replaced at the end.
KEY_FILE = WORK / "disk-key"
# The passphrase or recovery key that opens the partitions a reinstallation
# keeps, and a copy of it while the questions check it.
OLD_KEY_FILE = WORK / "old-key"
CHECK_KEY_FILE = WORK / "check-key"
LOG_FILE = WORK / "install.log"
LOCK_FILE = Path("/run/legion-install.lock")
TARGET_VOLUME = "legion-target"
KEEP_VOLUME = "legion-keep"
BOOT_PARTITION = Path("/dev/gpt-auto-root")
OVERLAY_LOWER = Path("/run/legion-live/lower")
# Password questions of systemd programs, for password agents
# (https://systemd.io/PASSWORD_AGENTS/).
ASK_PASSWORD = Path("/run/systemd/ask-password")

GIB = 1024**3
MIN_DISK_SIZE = 16 * GIB
# Room the GPT partition table needs at both ends of the disk, and more.
DISK_RESERVE = 2 * 1024**2
ESP_GIB = 1
# A root partition next to other partitions has at least this size (D-79);
# alone on the disk it takes the whole disk, from 16 GiB. With a separate
# /home it gets half of the disk unless you change it, from 20 to 50 GiB.
ROOT_MIN_GIB = 20
ROOT_DEFAULT_GIB = 50
PARTITION_MIN_GIB = 1
# How long to wait for udev after systemd-repart (wait_for_udev,
# find_partitions), in seconds.
UDEV_DELAY = 0.5
PARTITIONS_TIMEOUT = 15
# What logind must not do while install() runs (keep_awake).
KEEP_AWAKE = "sleep:handle-lid-switch"
# A GPT partition name holds 36 characters; folders of your own use it.
MAX_LABEL = 36
MAX_PARTITIONS = 16

# Kinds of partitions as systemd-repart names their types, with the GPT type
# UUIDs of the Discoverable Partitions Specification (root: x86-64).
TYPES = {
    "esp": "c12a7328-f81f-11d2-ba4b-00a0c93ec93b",
    "root": "4f68bce3-e8cd-4db1-96e7-fbcaf984b709",
    "home": "933ac7e1-2eb4-4f13-b844-0e14e2aef915",
    "srv": "3b8f8425-20e0-4f3b-907f-1a25a76f98e8",
    "var": "4d21b016-b534-45c2-a9fb-5c16e091fd2d",
    "tmp": "7ec6f557-3bc5-4aca-b293-16ef5df639d1",
    "swap": "0657fd6d-a4ab-43c4-84e5-0933c84b4f4f",
    "linux-generic": "0fc63daf-8483-4772-8e79-3d69d8477de4",
}
KIND_OF_TYPE = {type_uuid: kind for kind, type_uuid in TYPES.items()}
# Mount points with a partition type of their own. Any other folder gets a
# partition of the type linux-generic, named after the folder.
KINDS = {"/efi": "esp", "/": "root", "/home": "home", "/srv": "srv", "/var": "var",
         "/var/tmp": "tmp", "swap": "swap"}
MOUNTS = {kind: mount for mount, kind in KINDS.items()}
STANDARD_MOUNTS = ["/", "/home", "/var", "/srv", "/var/tmp", "swap"]
# What a reinstallation keeps; it creates the other partitions again (D-80).
KEPT_KINDS = ("home", "srv", "linux-generic")
FORMATS = {"esp": "vfat", "swap": "swap"}
# Names of encrypted volumes: those of systemd-gpt-auto-generator for the
# partition types it knows, and the folder for the others (see volume_name).
# The same names are the units of systemd-growfs@.service.
VOLUMES = {"/": "root", "/home": "home", "/srv": "srv", "/var": "var",
           "/var/tmp": "var-tmp", "swap": "swap"}
# Folders that cannot have a partition of their own: the system needs them
# before /etc/fstab is read, they are not on a disk, or they would need
# another way to start the computer (/usr, /boot). /tmp is in memory.
SYSTEM_FOLDERS = ("/bin", "/boot", "/dev", "/efi", "/etc", "/lib", "/lib32", "/lib64",
                  "/libx32", "/proc", "/root", "/run", "/sbin", "/sys", "/tmp", "/usr")
# Letters of systemd recovery keys (modhex), for reading one that was typed.
RECOVERY_KEY_LETTERS = set("cbdefghijklnrtuv")

DEFAULT_SWAP_FILE_GIB = 4
# Groups of 8 letters of the recovery key that you type from your note, chosen
# at random, to catch mistakes in writing it down (D-75).
RECOVERY_KEY_CHECKS = 2
LIVE_PACKAGES = ["legion-live", "legion-installer"]
ACCOUNT_GROUPS = ["sudo"]
# The image turns zram off with this link to /dev/null (D-48).
ZRAM_MASK = "etc/systemd/zram-generator.conf"
# On an encrypted disk the installer masks these units (D-72, D-79).
# systemd-repart 257 marks every partition of a type it knows for growing,
# even with GrowFileSystem=no, and systemd-growfs cannot resize an open LUKS2
# volume: it logs "crypt_resize() ... Operation not permitted" at every
# start. The partitions have their full size already.
GROWFS_ROOT_MASK = "etc/systemd/system/systemd-growfs-root.service"
GROWFS_MASK = "etc/systemd/system/systemd-growfs@{}.service"
CHROOT_ENV = {
    "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
    "LANG": "C.UTF-8",
    "HOME": "/root",
    "TERM": os.environ.get("TERM", "linux"),
}

# Layouts without Latin letters (D-78). As Debian does for them, the new
# system gets the US layout first and this one second, with Alt+Shift to
# switch, so user names and passwords can be typed in Latin letters. The list
# is the one of keyboard-configuration.config in console-setup 1.242~deb13u1;
# names that the XKB rules no longer have never match.
NON_LATIN_LAYOUTS = {
    "af", "am", "ara", "ben", "bd", "bg", "bt", "by", "et", "ge", "gh", "gr",
    "guj", "guru", "il", "in", "iq", "ir", "iku", "kan", "kh", "kz", "la", "lao",
    "lk", "kg", "ma", "mk", "mm", "mn", "mv", "mal", "np", "ori", "pk", "ru",
    "scc", "sy", "syr", "tel", "th", "tj", "tam", "tib", "ua", "ug", "uz",
}
# The XKB options Debian sets for two layouts: Alt+Shift switches them, and
# the Scroll Lock light is on with the second one.
SWITCH_OPTIONS = "grp:alt_shift_toggle,grp_led:scroll"

SWAP_CHOICES = [
    ("zram", "zram: compressed swap in RAM, fast and without writes to the disk (recommended)"),
    ("file", "swap file on the disk"),
    ("both", "both: zram first, then the swap file"),
    ("none", "no swap"),
]
# With a swap partition in the layout: a swap file would turn it off, because
# systemd-gpt-auto-generator leaves the partition alone when /etc/fstab has
# a swap.
SWAP_PARTITION_CHOICES = [
    ("zram", "zram first, then the swap partition (recommended)"),
    ("none", "only the swap partition"),
]

# Texts that both installers show.
PARTITIONS_TEXT = (
    "Legion divides the disk into partitions. One partition for everything is "
    "the simplest: the system and your files share all the space. With /home "
    "on a partition of its own, you can later install Legion again and keep "
    "your files, but each of the two partitions has a size of its own. Every "
    "layout also gets an EFI system partition of 1 GiB for starting the "
    "computer.")
HOME_SIZE_TEXT = (
    "Why these sizes: the root partition holds Legion and its updates, every "
    "program you install, also those from Flathub with their runtimes, the "
    "logs and the swap file. "
    "It needs at least 20 GiB, and 50 GiB gives room for years of updates and "
    "programs. /home holds your files and gets the rest of the disk, unless "
    "you give it a size; then the rest of the disk stays free. The two "
    "partitions do not share free space and their sizes are hard to change "
    "later, so on a small disk one partition for everything may use the space "
    "better.")
CUSTOM_TEXT = (
    "Every partition is mounted on a folder: /, /home, /var, /srv, /var/tmp or "
    "a folder of your own, such as /opt, or it is swap. Sizes are in GiB, and "
    "one partition can take the rest of the disk. The partitions get ext4, and "
    "with encryption all of them get LUKS2 with the same passphrase.")
ENCRYPTION_TEXT = (
    "Encryption protects your files when the computer is lost or stolen: "
    "without the passphrase nobody can read the disk. The computer then asks "
    "for the passphrase at every start. Encryption cannot be added later "
    "without installing Legion again.")
PASSPHRASE_TEXT = (
    "At every start the computer asks for this passphrase before Legion "
    "starts. Use at least 8 characters; a few unrelated words are easy to "
    "remember and hard to guess. You will also get a recovery key in case "
    "you forget it.")
OLD_PASSPHRASE_TEXT = (
    "The partitions you keep are encrypted. Type the disk passphrase you use "
    "now, or the recovery key, to open them. Below, choose the passphrase for "
    "the new system; it may be the same. You will get a new recovery key, and "
    "the old passphrase and recovery key stop working.")
NOT_ENCRYPTED_TEXT = (
    "The partitions you keep are not encrypted, so the new system is not "
    "encrypted either: encryption covers the whole disk or nothing.")
SECURITY_KEY_TEXT = (
    "A FIDO2 security key is connected. It can unlock the disk instead of "
    "the passphrase: you plug it in and touch it at start. The passphrase "
    "and the recovery key keep working.")
RECOVERY_KEY_TEXT = (
    "If you forget the disk passphrase, this key unlocks the disk instead. "
    "Write it down now and keep it in a safe place, away from this computer. "
    "It has only the letters c b d e f g h i j k l n r t u v. Take a photo of "
    "the screen, or write it in capital letters, so that u and n do not get "
    "mixed up.")
TWO_LAYOUTS_TEXT = (
    "This layout has no Latin letters, so Legion puts the US layout before "
    "it, as Debian does. Alt+Shift switches between the two. Type user names "
    "and passwords in the US layout: the computer starts with it.")

log_file = None
lock_file = None
cleanup_steps = []
disk_changed = False


class InstallError(Exception):
    pass


class Cancelled(Exception):
    pass


class Frontend:
    """What install() needs from a user interface. The text installer calls
    these methods from its only thread, the window from the thread that runs
    install()."""

    def step(self, text):
        """A step of the installation starts."""

    def running(self, time):
        """A long step still runs, after this time; about once a second."""

    def note(self, text):
        """A result of the current step, for example its time."""

    def keep_damaged_copy(self, lines):
        """dpkg --verify found package files that differ from their packages
        (its lines). Returns True to go on anyway."""
        return False

    def check_recovery_key(self, key):
        """Shows the recovery key and returns when the user has typed the
        groups of recovery_key_checks() from the note of it (D-75)."""
        raise NotImplementedError

    def add_security_key(self, enroll):
        """Lets the user add a FIDO2 security key. enroll(ask_pin) adds it
        (see enroll_security_key) and returns False when that failed.
        Returns whether the key was added."""
        raise NotImplementedError


class Partition:
    """A partition of the new system: the folder it is mounted on (or swap),
    its kind (the type name of systemd-repart) and its size in bytes, or None
    for the rest of the disk. For a reinstallation it also describes the
    partition on the disk, which it keeps or creates again."""

    def __init__(self, mount, size, minimum=0):
        self.mount = mount
        self.size = size
        self.minimum = minimum  # bytes, for the partition with the rest of the disk
        self.kind = KINDS.get(mount, "linux-generic")
        self.label = mount if self.kind == "linux-generic" else None
        self.keep = False
        self.encrypted = False  # an existing partition has LUKS2
        self.node = None  # the partition device, such as /dev/nvme0n1p3
        self.number = None  # its number in the partition table
        self.start = None  # in sectors of 512 bytes, for the order on the disk
        self.uuid = None  # PARTUUID of an existing partition
        self.device = None  # where its file system is during the installation

    @property
    def volume(self):
        return volume_name(self.mount)

    def __repr__(self):
        size = "rest" if self.size is None else f"{self.size / GIB:.1f}G"
        return f"{self.mount}:{self.kind}:{size}{':keep' if self.keep else ''}"


# Log and commands


def log(message):
    if log_file:
        log_file.write(f"{time.strftime('%H:%M:%S')} {message}\n")
        log_file.flush()


def log_tail(lines=15):
    try:
        return LOG_FILE.read_text(errors="replace").splitlines()[-lines:]
    except OSError:
        return []


def run(args, *, chroot=False, input=None, env=None, capture=False, check=True,
        interactive=False, hide_stderr=False):
    """Runs a command. Its output goes to the log, or with capture=True its
    standard output is returned. Secrets go only through input, env and
    files, which are never logged."""
    args = [str(a) for a in args]
    if chroot:
        args = ["chroot", str(TARGET), *args]
        env = {**CHROOT_ENV, **(env or {})}
    elif env:
        env = {**os.environ, **env}
    log("$ " + shlex.join(args))
    if interactive:
        result = subprocess.run(args, env=env)
        output = ""
    else:
        stderr = subprocess.DEVNULL if hide_stderr else (log_file or subprocess.DEVNULL)
        result = subprocess.run(
            args, env=env, text=True,
            input=input, stdin=None if input is not None else subprocess.DEVNULL,
            stdout=subprocess.PIPE if capture else (log_file or subprocess.DEVNULL),
            stderr=stderr if capture else subprocess.STDOUT,
        )
        output = result.stdout if capture else ""
    if result.returncode != 0:
        log(f"exit status {result.returncode}")
        if check:
            raise InstallError(f"{shlex.join(args[:4])} failed (exit status {result.returncode}).")
    return output if capture else result.returncode


def run_long(args, title, ui, *, chroot=False):
    """Runs a long command and tells the user interface how long it runs."""
    args = [str(a) for a in args]
    env = None
    if chroot:
        args = ["chroot", str(TARGET), *args]
        env = CHROOT_ENV
    ui.step(title)
    log("$ " + shlex.join(args))
    start = time.monotonic()
    with subprocess.Popen(args, env=env, stdin=subprocess.DEVNULL,
                          stdout=log_file, stderr=subprocess.STDOUT) as process:
        while True:
            try:
                code = process.wait(timeout=1)
                break
            except subprocess.TimeoutExpired:
                ui.running(elapsed(start))
    log(f"exit status {code} after {elapsed(start)}")
    if code != 0:
        raise InstallError(f"{shlex.join(args[:4])} failed (exit status {code}).")
    ui.note(f"done in {elapsed(start)}")


def run_answering_passwords(args, ask):
    """Runs a command without a terminal and answers its password questions
    as a password agent (https://systemd.io/PASSWORD_AGENTS/): the command
    writes a question to /run/systemd/ask-password/ and waits for the answer
    on a socket. ask(message, again) returns the answer, or None to cancel
    the question; again is True from the second question on, for example
    after a wrong PIN. Only questions of this command are answered. Returns
    the exit status."""
    args = [str(a) for a in args]
    log("$ " + shlex.join(args))
    answered = set()
    with subprocess.Popen(args, stdin=subprocess.DEVNULL,
                          stdout=log_file or subprocess.DEVNULL, stderr=subprocess.STDOUT) as process:
        while process.poll() is None:
            for path, question in password_questions(process.pid):
                if path not in answered:
                    answered.add(path)
                    send_password(question["Socket"], ask(question.get("Message", ""), len(answered) > 1))
            time.sleep(0.2)
    log(f"exit status {process.returncode}")
    return process.returncode


def password_questions(pid):
    """Password questions of the process pid that wait for an agent."""
    questions = []
    for path in sorted(ASK_PASSWORD.glob("ask.*")):
        question = read_assignments(path)
        if question.get("PID") == str(pid) and question.get("Socket"):
            questions.append((path, question))
    return questions


def send_password(socket_path, password):
    """Answers a password question on its socket; None cancels it."""
    packet = b"-" if password is None else b"+" + password.encode()
    with socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM) as sock:
        try:
            sock.sendto(packet, socket_path)
        except OSError as error:  # the question is gone
            log(f"password agent: {error}")


def elapsed(start):
    seconds = int(time.monotonic() - start)
    return f"{seconds // 60} min {seconds % 60:02d} s" if seconds >= 60 else f"{seconds} s"


def write_secret(path, text):
    """Writes a key or passphrase to a file that only root can read, without
    a newline at the end: tools read the whole file as the key."""
    path.unlink(missing_ok=True)
    old_umask = os.umask(0o077)
    try:
        path.write_text(text)
    finally:
        os.umask(old_umask)


# Facts about the live system


def read_assignments(path):
    """KEY=value lines, as in /etc/default/keyboard and /etc/locale.conf."""
    values = {}
    try:
        for line in Path(path).read_text().splitlines():
            key, sep, value = line.partition("=")
            if sep and not key.strip().startswith("#"):
                values[key.strip()] = value.strip().strip('"')
    except OSError:
        pass
    return values


def load_locales():
    """UTF-8 locales from the list of glibc, for example pl_PL.UTF-8."""
    locales = {}
    for line in Path("/usr/share/i18n/SUPPORTED").read_text().splitlines():
        parts = line.split()
        if len(parts) == 2 and parts[1] == "UTF-8":
            locales[parts[0]] = line.strip()
    return locales


def language_name(locale):
    """The name of a locale from its definition in glibc, for example
    "Polish (Poland)" for pl_PL.UTF-8, or "" when it has none."""
    base, _, modifier = locale.partition("@")
    path = Path("/usr/share/i18n/locales") / (base.split(".")[0] + (f"@{modifier}" if modifier else ""))
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    section = re.search(r"^LC_IDENTIFICATION$(.*?)^END LC_IDENTIFICATION", text, re.M | re.S)
    if not section:
        return ""
    names = {}
    for key in ("language", "territory"):
        found = re.search(rf'^{key}\s+"([^"]*)"', section.group(1), re.M)
        names[key] = found.group(1) if found else ""
    details = ", ".join(filter(None, [names["territory"], modifier]))
    return f"{names['language']} ({details})" if names["language"] and details else names["language"]


def load_keyboard_layouts():
    """Layouts and their variants from the XKB rules."""
    layouts, variants = {}, {}
    section = None
    for line in Path("/usr/share/X11/xkb/rules/base.lst").read_text(encoding="utf-8").splitlines():
        if line.startswith("! "):
            section = line[2:].strip()
            continue
        name, _, description = line.strip().partition(" ")
        if not name:
            continue
        description = description.strip()
        if section == "layout":
            layouts[name] = description
        elif section == "variant":
            layout, _, text = description.partition(":")
            variants.setdefault(layout.strip(), {})[name] = text.strip()
    return layouts, variants


def load_timezones(links=True):
    """Time zone names as systemd lists them, from tzdata.zi. Without links,
    only the zones themselves, without old names such as Europe/Kiev."""
    names = {"UTC"}
    for line in Path("/usr/share/zoneinfo/tzdata.zi").read_text().splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[0] == "Z":
            names.add(parts[1])
        elif links and len(parts) >= 3 and parts[0] == "L":
            names.add(parts[2])
    return sorted(names)


def current_timezone():
    try:
        return os.readlink("/etc/localtime").split("zoneinfo/", 1)[1]
    except (OSError, IndexError):
        return "UTC"


def existing_names():
    names = set()
    for path in ("/etc/passwd", "/etc/group"):
        for line in Path(path).read_text().splitlines():
            names.add(line.split(":", 1)[0])
    return names


def block_devices(*devices):
    output = run(["lsblk", "--json", "--bytes", "--output",
                  "NAME,PATH,TYPE,SIZE,RO,TRAN,MODEL,PARTTYPE,FSTYPE,MOUNTPOINTS", *devices],
                 capture=True)
    return json.loads(output)["blockdevices"]


def partition_table(disk):
    """The disk with its partitions, as lsblk shows them, and the partitions
    in the order of their start on the disk. lsblk puts the partitions under
    the disk only with the NAME column: without it, lsblk 2.41 prints a flat
    list (installer 5 and 6 never found the partitions because of that)."""
    output = run(["lsblk", "--json", "--bytes", "--output",
                  "NAME,PATH,TYPE,SIZE,PTTYPE,PARTTYPE,PARTLABEL,PARTUUID,PARTN,START,FSTYPE,UUID", disk],
                 capture=True)
    device = json.loads(output)["blockdevices"][0]
    partitions = sorted((d for d in walk(device) if d["type"] == "part"), key=lambda d: d.get("start") or 0)
    return device, partitions


def walk(device):
    yield device
    for child in device.get("children") or []:
        yield from walk(child)


def in_use(disk):
    """Mounted parts of a disk, and devices built on it, such as an open
    encrypted volume."""
    return [d["path"] for d in walk(disk)
            if any(d.get("mountpoints") or []) or d["type"] not in ("disk", "part")]


def parent_disk(partition):
    name = run(["lsblk", "--nodeps", "--noheadings", "--output", "PKNAME", partition],
               capture=True).strip()
    return f"/dev/{name}" if name else None


def disk_id(path):
    """A stable name from /dev/disk/by-id/, as D-59 asks for."""
    by_id = Path("/dev/disk/by-id")
    names = sorted(p.name for p in by_id.iterdir() if os.path.realpath(p) == path) if by_id.is_dir() else []
    for prefix in ("nvme-", "ata-", "usb-", "mmc-", "scsi-", "virtio-"):
        for name in names:
            if name.startswith(prefix) and not name.startswith("nvme-eui."):
                return name
    return names[0] if names else None


def disk_size(disk):
    return f"{disk['size'] / GIB:.1f} GiB"


def disk_model(disk):
    return (disk.get("model") or "").strip() or "unknown model"


def disk_contents(disk):
    """File systems and other contents found on the disk, such as ext4 or crypto_LUKS."""
    return sorted({d.get("fstype") for d in walk(disk) if d is not disk and d.get("fstype")})


def describe_disk(disk):
    transport = (disk.get("tran") or "").upper()
    contents = disk_contents(disk)
    text = f"{disk['path']}  {disk_size(disk)}  {disk_model(disk)}{f'  ({transport})' if transport else ''}"
    text += f"\n       now: {', '.join(contents)}" if contents else "\n       now: no partitions found"
    return text


def fido2_devices():
    output = run(["systemd-cryptenroll", "--fido2-device=list"], capture=True, check=False)
    return [line.split()[0] for line in output.splitlines() if line.startswith("/dev/")]


# Checks before the questions


def check_environment():
    """Raises InstallError when Legion cannot be installed from this system.
    Both installers check first that they run as root."""
    if "legion.live" not in Path("/proc/cmdline").read_text().split():
        raise InstallError(
            "The installer works only in the live session: start Legion from the "
            "USB stick with the default entry of the boot menu (RAM mode) or with "
            "Low memory mode.")
    if not Path("/sys/firmware/efi/efivars").is_dir():
        raise InstallError(
            "This computer did not start in UEFI mode. Legion needs UEFI: turn off "
            "the legacy (CSM) mode in the firmware settings and start again.")


def lock():
    """Makes sure that only one installer runs: a second one would close the
    disk volumes of the first (remove_leftovers) or install on the same disk.
    The lock lasts until the program ends."""
    global lock_file
    lock_file = open(LOCK_FILE, "a")
    try:
        fcntl.flock(lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise InstallError("Another Legion installer is running. Close it first, or wait until it ends.")


def remove_leftovers():
    """Closes the disk volumes of an earlier, interrupted run."""
    mapper = Path("/dev/mapper")
    for path in sorted(mapper.glob(f"{TARGET_VOLUME}*")) + sorted(mapper.glob(f"{KEEP_VOLUME}*")):
        run(["systemd-cryptsetup", "detach", path.name], check=False)


def find_boot_partition():
    """The root partition of the Legion USB stick, or None when it is not
    connected. The installer copies the system from it."""
    return os.path.realpath(BOOT_PARTITION) if BOOT_PARTITION.exists() else None


def candidate_disks(boot_disk):
    """Disks Legion can be installed on and disks that are too small for it,
    without the USB stick it started from."""
    disks = [d for d in block_devices()
             if d["type"] == "disk" and not d["ro"] and d["path"] != boot_disk
             and not d["name"].startswith(("zram", "ram"))]
    return ([d for d in disks if d["size"] >= MIN_DISK_SIZE],
            [d for d in disks if d["size"] < MIN_DISK_SIZE])


# Checks of the answers: they return the value to use or raise ValueError with
# a message for the user.


def check_hostname(answer):
    if re.fullmatch(r"[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?", answer):
        return answer
    raise ValueError("Use 1 to 63 lowercase letters, digits and hyphens, without a hyphen at the ends.")


def check_full_name(answer):
    if any(c in answer for c in ":,=\n"):
        raise ValueError("Do not use the characters : , and =.")
    return answer


def check_user_name(answer, taken):
    if not re.fullmatch(r"[a-z][a-z0-9_-]{0,31}", answer):
        raise ValueError("Start with a lowercase letter, then use lowercase letters, digits, - and _ (at most 32).")
    if answer in taken:
        raise ValueError(f"The name {answer} is already used by the system. Choose another one.")
    return answer


def suggested_user_name(full_name, taken):
    """The first name in lowercase, if it makes a valid user name."""
    words = full_name.split()
    try:
        return check_user_name(words[0].lower(), taken) if words else None
    except ValueError:
        return None


def check_password(answer):
    if not answer:
        raise ValueError("The password cannot be empty.")
    return answer


def check_disk_passphrase(answer):
    if len(answer) < 8:
        raise ValueError("Use at least 8 characters.")
    return answer


def swap_file_limit(root_size):
    """The largest swap file in GiB: a quarter of the root partition, from 1 to 32."""
    return max(1, min(32, root_size // GIB // 4))


def keyboard_settings(layout, variant):
    """XKBLAYOUT, XKBVARIANT and XKBOPTIONS of the new system for the chosen
    layout and variant (D-78)."""
    if layout in NON_LATIN_LAYOUTS:
        return f"us,{layout}", f",{variant}", SWITCH_OPTIONS
    return layout, variant, ""


def session_keyboard():
    """XKBLAYOUT, XKBVARIANT and XKBOPTIONS of the live session."""
    keyboard = read_assignments("/etc/default/keyboard")
    return (keyboard.get("XKBLAYOUT", "") or "us", keyboard.get("XKBVARIANT", ""),
            keyboard.get("XKBOPTIONS", ""))


def set_session_keyboard(layout, variant="", options=""):
    """Switches the keyboard of the live session (D-73) to XKB settings,
    comma-separated as in /etc/default/keyboard. sudo and pkexec keep DISPLAY
    and XAUTHORITY, so setxkbmap reaches the desktop. Without a variant,
    setxkbmap also clears the variant set before, and the empty -option
    clears the options set before."""
    if not os.environ.get("DISPLAY") or not shutil.which("setxkbmap"):
        return False
    args = ["setxkbmap", "-layout", layout]
    if variant.strip(","):
        args += ["-variant", variant]
    args += ["-option", ""]
    for option in filter(None, options.split(",")):
        args += ["-option", option]
    return run(args, check=False, hide_stderr=True) == 0


def recovery_key_checks(key):
    """Numbers of the groups of the recovery key to type from the note,
    chosen at random (D-75)."""
    count = len(key.split("-"))
    return sorted(secrets.SystemRandom().sample(range(1, count + 1), RECOVERY_KEY_CHECKS))


def recovery_group_matches(key, number, answer):
    """Whether the answer is that group of the key, in any case and with or
    without spaces."""
    return answer.replace(" ", "").lower() == key.split("-")[number - 1]


def disk_secret(answer):
    """The passphrase or recovery key that opens the partitions a
    reinstallation keeps. A recovery key may be typed in capital letters,
    with spaces or without dashes; the disk knows it in small letters with
    dashes."""
    letters = answer.replace(" ", "").replace("-", "").lower()
    if len(letters) == 64 and set(letters) <= RECOVERY_KEY_LETTERS:
        return "-".join(letters[i:i + 8] for i in range(0, 64, 8))
    if not answer:
        raise ValueError("Type the passphrase or the recovery key.")
    return answer


# Layouts (D-79, D-80). A layout is a list of (mount, size): the folder of a
# partition, or swap, and its size in GiB, or None for the rest of the disk.
# The EFI system partition comes first in every layout and is not in the list.


def volume_name(mount):
    """The name of the encrypted volume of a partition and of its key file in
    /etc/cryptsetup-keys.d/: the one systemd-gpt-auto-generator uses, or for
    a folder of your own the folder with - for /, such as var-log."""
    return VOLUMES.get(mount) or mount.strip("/").replace("/", "-")


def is_under(path, folder):
    """Whether the folder path is inside folder."""
    if not path.startswith("/") or path == folder:
        return False
    return folder == "/" or path.startswith(folder + "/")


def check_mount(answer):
    """The mount point of a partition from what was typed: swap or a folder,
    such as /home or /opt."""
    answer = answer.strip()
    if answer.lower() == "swap":
        return "swap"
    if not answer.startswith("/"):
        raise ValueError("Type a folder that starts with /, such as /opt, or swap.")
    path = "/" + "/".join(name for name in answer.split("/") if name)
    if path == "/":
        return path
    for name in path.split("/")[1:]:
        if name.startswith(".") or not re.fullmatch(r"[A-Za-z0-9._-]+", name):
            raise ValueError("Use letters, digits, dots, - and _ in folder names, without a dot at the start.")
    if len(path) > MAX_LABEL:
        raise ValueError(f"Use at most {MAX_LABEL} characters.")
    for folder in SYSTEM_FOLDERS:
        if path == folder or is_under(path, folder):
            raise ValueError(f"{folder} cannot have a partition of its own: Legion needs it to start, "
                             "or it is not on the disk.")
    # A link, such as /var/run to /run, would put the partition elsewhere.
    prefix = ""
    for name in path.split("/")[1:]:
        prefix += "/" + name
        if os.path.islink(prefix):
            raise ValueError(f"{prefix} is a link to {os.readlink(prefix)}. Use the folder it points to.")
    return path


def minimum_size(mount, layout):
    """The smallest size of a partition in GiB, or 0 for a root partition
    alone on the disk."""
    if mount == "/":
        return ROOT_MIN_GIB if len(layout) > 1 else 0
    return PARTITION_MIN_GIB


def usable_gib(disk_size):
    """Room for partitions on a disk, in GiB."""
    return (disk_size - DISK_RESERVE) / GIB


def gib_text(value):
    """GiB with one decimal, rounded down, so that the rest of a disk never
    looks larger than the largest whole size you can type."""
    return f"{math.floor(value * 10) / 10:.1f} GiB"


def rest_size(layout, disk_size):
    """GiB left after the EFI system partition and the partitions with a
    size: for the partition with the rest of the disk, or free space."""
    return usable_gib(disk_size) - ESP_GIB - sum(size for _, size in layout if size is not None)


def largest_root(disk_size):
    """The largest root partition in GiB that leaves 1 GiB for /home."""
    return int(usable_gib(disk_size) - ESP_GIB - PARTITION_MIN_GIB)


def largest_home(disk_size, root):
    """The largest /home in GiB next to a root partition of root GiB."""
    return int(usable_gib(disk_size) - ESP_GIB - root)


def separate_home_possible(disk_size):
    """Whether the disk has room for a root partition of 20 GiB and /home."""
    return largest_root(disk_size) >= ROOT_MIN_GIB


def default_root_size(disk_size):
    """The root partition next to /home unless you change it: half of the
    disk, from 20 to 50 GiB (D-79)."""
    half = int((usable_gib(disk_size) - ESP_GIB) / 2)
    return min(max(half, ROOT_MIN_GIB), ROOT_DEFAULT_GIB, largest_root(disk_size))


def single_layout():
    """One partition for everything: the layout of a disk unless you change
    it, as in Debian and Ubuntu (D-81)."""
    return [("/", None)]


def separate_home_layout(disk_size, root=None, home=None):
    """The root partition of root GiB, half of the disk unless you change
    it, and /home of home GiB or, with None, on the rest of the disk (D-79,
    D-81)."""
    root = default_root_size(disk_size) if root is None else min(root, largest_root(disk_size))
    return [("/", root), ("/home", home)]


def custom_layout_start(disk_size):
    """The layout the custom editor starts from: a separate /home where it
    fits, as an example to change, else one partition."""
    return separate_home_layout(disk_size) if separate_home_possible(disk_size) else single_layout()


def layout_choices(disk_size):
    """The layouts to choose from. The first one, one partition for
    everything, is the default (D-81). A separate /home only where a root
    partition of 20 GiB and /home fit."""
    choices = [("single", "One partition for everything (recommended)")]
    if separate_home_possible(disk_size):
        choices.append(("home", "Separate partition for /home: the system on one partition, your files on another"))
    choices.append(("custom", "Custom partitions, for those who know Linux"))
    return choices


def check_layout(layout, disk_size):
    """Problems of a layout on a disk of disk_size bytes, as messages for the
    user; an empty list when it is good."""
    problems = []
    mounts = [mount for mount, _ in layout]
    if "/" not in mounts:
        problems.append("Add the root partition, /.")
    for mount in sorted(set(mounts)):
        if mounts.count(mount) > 1:
            problems.append(f"{mount} is in the list more than once.")
    for mount in mounts:
        try:
            check_mount(mount)
        except ValueError as error:
            problems.append(f"{mount}: {error}")
    volumes = {}
    for mount in mounts:
        volumes.setdefault(volume_name(mount), set()).add(mount)
    for name, same in sorted(volumes.items()):
        if len(same) > 1:
            problems.append(f"{' and '.join(sorted(same))} would get the same volume name, {name}. "
                            "Rename one of them.")
    if sum(1 for _, size in layout if size is None) > 1:
        problems.append("Only one partition can take the rest of the disk.")
    for mount, size in layout:
        least = max(minimum_size(mount, layout), PARTITION_MIN_GIB)
        if size is not None and size < least:
            problems.append(f"{mount} needs at least {least} GiB.")
    if len(layout) + 1 > MAX_PARTITIONS:
        problems.append(f"Use at most {MAX_PARTITIONS} partitions, with the EFI system partition.")
    needed = ESP_GIB + sum(size for _, size in layout if size is not None)
    needed += sum(max(minimum_size(mount, layout), PARTITION_MIN_GIB) for mount, size in layout if size is None)
    if needed > usable_gib(disk_size):
        problems.append(f"The partitions need {needed} GiB, but the disk has room for "
                        f"{gib_text(usable_gib(disk_size))}.")
    return problems


def describe_layout(layout, disk_size):
    """The partitions of a layout with their sizes, for the summary."""
    rest = rest_size(layout, disk_size)
    texts = [f"/efi {ESP_GIB} GiB"]
    for mount, size in layout:
        texts.append(f"{mount} {size} GiB" if size is not None else f"{mount} {gib_text(rest)} (rest of the disk)")
    if all(size is not None for _, size in layout) and rest >= 0.1:
        texts.append(f"{gib_text(rest)} free")
    return ", ".join(texts)


def new_partitions(layout):
    """The partitions of a layout on an erased disk."""
    parts = [Partition("/efi", ESP_GIB * GIB)]
    for mount, size in layout:
        parts.append(Partition(mount, None if size is None else size * GIB,
                               minimum_size(mount, layout) * GIB))
    return parts


# Reinstallation (D-79, D-80)


def find_legion(disk):
    """The partitions of a Legion found on the disk, in their order on the
    disk, with keep set on those a reinstallation keeps. None when the disk
    does not have the partitions of a Legion installer or nothing to keep:
    every partition must be of a kind the installer creates, and folders of
    your own must be named after their folder."""
    device, rows = partition_table(disk)
    if device.get("pttype") != "gpt" or not rows:
        return None
    parts = []
    for row in rows:
        kind = KIND_OF_TYPE.get((row.get("parttype") or "").lower())
        if kind is None:
            return None
        if kind == "linux-generic":
            try:
                mount = check_mount(row.get("partlabel") or "")
            except ValueError:
                return None
            if mount in KINDS:
                return None
        else:
            mount = MOUNTS[kind]
        part = Partition(mount, row["size"])
        part.label = row.get("partlabel") if kind == "linux-generic" else None
        part.node = row["path"]
        part.number = row.get("partn")
        part.start = row.get("start")
        part.uuid = row.get("partuuid")
        part.keep = kind in KEPT_KINDS
        fstype = row.get("fstype")
        part.encrypted = kind != "esp" and fstype == "crypto_LUKS"
        if not part.encrypted and fstype != FORMATS.get(kind, "ext4"):
            return None
        parts.append(part)
    mounts = [p.mount for p in parts]
    if mounts.count("/efi") != 1 or mounts.count("/") != 1 or len(set(mounts)) != len(mounts):
        return None
    if len({p.encrypted for p in parts if p.kind != "esp"}) != 1:
        return None
    if not any(p.keep for p in parts):
        return None
    return parts


def kept_mounts(parts):
    return [p.mount for p in parts if p.keep]


def replaced_mounts(parts):
    return [p.mount for p in parts if not p.keep]


def reinstall_text(parts):
    """What a reinstallation does with the partitions found on the disk."""
    kept = ", ".join(kept_mounts(parts))
    replaced = ", ".join(m for m in replaced_mounts(parts) if m != "/efi")
    text = (f"Legion is installed on this disk. The installer can install it again and keep "
            f"{kept} with their files: it creates the EFI system partition and {replaced} again, "
            "with a new copy of Legion.")
    if "/home" in kept_mounts(parts):
        text += (" Your account gets the name and number (UID) of its folder in /home. Programs "
                 "from Flathub have to be installed again; their data in your folder stays.")
    return text


def is_encrypted(parts):
    return any(p.encrypted for p in parts)


def kept_home_folders(parts, secret):
    """Opens the partitions a reinstallation keeps, read-only, with the
    passphrase or recovery key (None without encryption), and returns the
    folders in /home as (name, uid, gid). Raises ValueError when the key does
    not open them. Every partition closes again at once."""
    opened = []
    devices = {}
    WORK.mkdir(mode=0o700, exist_ok=True)
    try:
        if secret is not None:
            write_secret(CHECK_KEY_FILE, secret)
        for part in parts:
            if not part.keep:
                continue
            devices[part.mount] = part.node
            if part.encrypted:
                name = f"{KEEP_VOLUME}-{part.number}"
                code = run(["systemd-cryptsetup", "attach", name, part.node, CHECK_KEY_FILE,
                            "luks,read-only,tries=1"], check=False, hide_stderr=True)
                if code != 0:
                    raise ValueError(f"This passphrase or recovery key does not open {part.mount}. "
                                     "Type the one you use now.")
                opened.append(name)
                devices[part.mount] = f"/dev/mapper/{name}"
        return home_folders(devices["/home"]) if "/home" in devices else []
    finally:
        for name in reversed(opened):
            run(["systemd-cryptsetup", "detach", name], check=False)
        CHECK_KEY_FILE.unlink(missing_ok=True)


def home_folders(device):
    """Folders in the top folder of the ext4 file system on device, as
    (name, uid, gid), read with debugfs without mounting it."""
    output = run(["debugfs", "-R", "ls -p /", device], capture=True, check=False, hide_stderr=True)
    folders = []
    for line in output.splitlines():
        # /inode/mode/uid/gid/name/size/
        fields = line.split("/")
        if (len(fields) >= 7 and fields[2].startswith("04")
                and fields[5] not in (".", "..", "lost+found")):
            folders.append((fields[5], int(fields[3]), int(fields[4])))
    return sorted(folders)


def recreated_partitions(parts):
    """The partitions a reinstallation creates again. systemd-repart creates
    one per run, in the room of the old one: its first-fit allocation puts a
    new partition into the smallest free area it fits in, so with several
    in one run a small one could take the room of another, or free space
    elsewhere on the disk, such as after a /home of its own size (D-81)."""
    return [part for part in parts if not part.keep]


# Summary


def has_swap_partition(answers):
    return "swap" in [p.mount for p in answers["reinstall"]] if answers.get("reinstall") \
        else "swap" in [mount for mount, _ in answers["layout"]]


def swap_choices(answers):
    return SWAP_PARTITION_CHOICES if has_swap_partition(answers) else SWAP_CHOICES


def root_size(answers):
    """The size of the root partition in bytes, which holds the swap file."""
    if answers.get("reinstall"):
        return next(p.size for p in answers["reinstall"] if p.mount == "/")
    size = dict(answers["layout"])["/"]
    return size * GIB if size is not None else int(rest_size(answers["layout"], answers["disk"]["size"]) * GIB)


def describe_partitions(answers):
    if answers.get("reinstall"):
        parts = answers["reinstall"]
        return (f"Legion installed again: {', '.join(replaced_mounts(parts))} created again, "
                f"{', '.join(kept_mounts(parts))} kept")
    return describe_layout(answers["layout"], answers["disk"]["size"])


def summary(answers, layouts):
    """The answers other than the disk, as (title, text) for the summary."""
    layout, variant = answers["keyboard"]
    full_name, user, _ = answers["account"]
    swap, size = answers["swap"]
    keyboard = f"{layout} ({layouts[layout]}){f', variant {variant}' if variant else ''}"
    if layout in NON_LATIN_LAYOUTS:
        keyboard += ", after us (Alt+Shift switches)"
    if answers["encrypt"]:
        keys = ["passphrase", "recovery key"] + (["security key"] if answers["fido2"] else [])
        encryption = f"yes ({', '.join(keys)})"
    else:
        encryption = "no"
    account = f"{user}{f' ({full_name})' if full_name else ''}, administrator"
    if answers.get("home_owner"):
        account += f", UID {answers['home_owner'][0]} of /home/{user}"
    if has_swap_partition(answers):
        swap_text = "zram, then the swap partition" if swap == "zram" else "the swap partition"
    else:
        swap_text = f"{swap}{f', swap file {size} GiB' if size else ''}"
    return [
        ("Partitions", describe_partitions(answers)),
        ("Language", answers["language"]),
        ("Keyboard", keyboard),
        ("Time zone", answers["timezone"]),
        ("Computer name", answers["hostname"]),
        ("Account", account),
        ("Encryption", encryption),
        ("Swap", swap_text),
    ]


def next_steps(answers, result):
    """What to do after the installation, as paragraphs."""
    user = answers["account"][1]
    steps = ["Restart the computer and remove the USB stick when the screen goes dark."]
    if answers["encrypt"]:
        steps.append(f"At start, type the disk passphrase, then log in as {user}. "
                     "The recovery key works instead of the passphrase: type it in small "
                     "letters, with the dashes.")
        if not result["security_key"]:
            steps.append("To add a FIDO2 security key later, run in the new system:\n"
                         f"    sudo systemd-cryptenroll --fido2-device=auto {result['root']}")
    else:
        steps.append(f"Then log in as {user}.")
    if answers.get("reinstall"):
        steps.append("Programs you installed from Flathub have to be installed again. "
                     "Their data in your folder stays.")
    return steps


# Installation steps


def start_log():
    global log_file
    WORK.mkdir(mode=0o700, exist_ok=True)
    os.chmod(WORK, 0o700)
    log_file = open(LOG_FILE, "a")
    os.chmod(LOG_FILE, 0o600)
    log(f"legion-install {VERSION}")


def private_mounts():
    """Mounts made from now on stay in this thread and its child processes:
    unshare() gives a new mount namespace only to the calling thread."""
    os.unshare(os.CLONE_NEWNS)
    run(["mount", "--make-rprivate", "/"])


def keep_awake():
    """Keeps the computer awake until cleanup(), so that closing the lid of
    a laptop does not suspend it in the middle of the installation. On the
    desktop xfce4-power-manager handles the lid (D-52) and asks logind to
    suspend; a "sleep" lock in block mode makes logind refuse that, also for
    the live account, which polkit allows everything. Without a desktop
    logind handles the lid itself and ignores "sleep" locks for it
    (LidSwitchIgnoreInhibited=yes), but not a "handle-lid-switch" lock.
    systemd-inhibit holds the lock while cat runs, and cat ends when
    cleanup() closes its input or the installer ends. systemd-inhibit starts
    cat only after logind gave the lock, so a line that cat repeats proves
    it. Returns whether the lock is held."""
    args = ["systemd-inhibit", f"--what={KEEP_AWAKE}", "--who=Legion installer",
            "--why=Installing Legion", "--mode=block", "--no-ask-password", "cat"]
    log("$ " + shlex.join(args))
    process = subprocess.Popen(args, text=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                               stderr=log_file or subprocess.DEVNULL)

    def release():
        try:
            process.stdin.close()
        except BrokenPipeError:
            pass
        process.stdout.close()
        log(f"systemd-inhibit ended: exit status {process.wait(timeout=10)}")

    cleanup_steps.append(release)
    try:
        process.stdin.write("held\n")
        process.stdin.flush()
    except BrokenPipeError:
        pass
    held = process.stdout.readline() == "held\n"
    log(f"sleep and the lid switch blocked: {'yes' if held else 'no'}")
    return held


def mount_source(boot_partition, boot_disk):
    if os.path.ismount(OVERLAY_LOWER):
        source = OVERLAY_LOWER
        log(f"source: read-only layer of overlay mode, {OVERLAY_LOWER}")
    else:
        SOURCE.mkdir(exist_ok=True)
        run(["mount", "-o", "ro", boot_partition, SOURCE])
        source = SOURCE
    esp = [d["path"] for d in walk(block_devices(boot_disk)[0]) if d.get("parttype") == TYPES["esp"]]
    if len(esp) != 1:
        raise InstallError(f"The EFI system partition of the USB stick ({boot_disk}) was not found.")
    SOURCE_ESP.mkdir(exist_ok=True)
    run(["mount", "-o", "ro", esp[0], SOURCE_ESP])
    # The kernel package puts vmlinuz, config and System.map in /boot, which
    # is the EFI system partition in the image. They go to /boot on the
    # root partition of the new system.
    kernels = sorted(p.name for p in (source / "usr/lib/modules").iterdir()
                     if (SOURCE_ESP / f"vmlinuz-{p.name}").is_file())
    if not kernels:
        raise InstallError("No kernel was found on the USB stick.")
    log(f"kernels: {' '.join(kernels)}")
    return source, kernels


def check_account(source, answers):
    """Raises InstallError, before the disk changes, when the account cannot
    get the number of its folder in /home: another account of the new system
    has it."""
    owner = answers.get("home_owner")
    if not owner:
        return
    user = answers["account"][1]
    for line in (source / "etc/passwd").read_text().splitlines():
        fields = line.split(":")
        if len(fields) > 2 and fields[2] == str(owner[0]) and fields[0] != user:
            raise InstallError(f"The account {fields[0]} of the new system has the number {owner[0]} of "
                               f"/home/{user}. Nothing was changed on the disk.")


def definition(part, parts, source, encrypt, reset):
    """The systemd-repart definition of a partition. An existing partition
    that the installation keeps gets only its type and its size as the
    largest one, so that systemd-repart does not make it larger. A new one
    gets the folder of the USB stick it is mounted on (CopyFiles=), without
    the folders of other partitions in it (ExcludeFiles= with / at the end
    leaves the empty folder as a mount point)."""
    lines = ["[Partition]", f"Type={part.kind}"]
    if part.label:
        lines.append(f"Label={part.label}")
    if part.keep:
        lines.append(f"SizeMaxBytes={part.size}")
        return "\n".join(lines) + "\n"
    lines.append(f"Format={FORMATS.get(part.kind, 'ext4')}")
    if part.kind not in ("esp", "swap"):
        if part.mount == "/":
            lines.append("CopyFiles=/")
        elif (source / part.mount[1:]).is_dir():
            lines.append(f"CopyFiles={part.mount}:/")
        for other in parts:
            if other.kind not in ("esp", "swap") and is_under(other.mount, part.mount):
                lines.append(f"ExcludeFiles={other.mount}/")
    if part.size is not None:
        lines += [f"SizeMinBytes={part.size}", f"SizeMaxBytes={part.size}"]
    elif part.minimum:
        lines.append(f"SizeMinBytes={part.minimum}")
    if encrypt and part.kind != "esp":
        lines.append("Encrypt=key-file")
    if any(part is other for other in reset):
        lines.append("FactoryReset=yes")
    return "\n".join(lines) + "\n"


def write_definitions(parts, source, encrypt, reset=()):
    """Writes the definitions for systemd-repart, one file per partition in
    their order on the disk. It matches existing partitions to definitions
    of the same type in this order."""
    shutil.rmtree(DEFINITIONS, ignore_errors=True)
    DEFINITIONS.mkdir(mode=0o700)
    for number, part in enumerate(parts, start=1):
        name = f"{number:02d}-{part.kind}.conf"
        text = definition(part, parts, source, encrypt, reset)
        (DEFINITIONS / name).write_text(text)
        log(f"{DEFINITIONS / name}:\n" + "".join(f"    {line}\n" for line in text.splitlines()))


def partition_and_copy(answers, source, machine_id, ui):
    """Creates the partitions of the layout, or for a reinstallation the
    partitions of the system again, and returns them with their devices."""
    global disk_changed
    disk = answers["disk"]["path"]
    encrypt = answers["encrypt"]
    args = ["systemd-repart", "--dry-run=no", "--offline=no", f"--seed={machine_id}",
            "--no-pager", "--pretty=no", f"--definitions={DEFINITIONS}"]
    if encrypt:
        # A temporary key, replaced by your passphrase at the end.
        write_secret(KEY_FILE, secrets.token_hex(32))
        args.append(f"--key-file={KEY_FILE}")
    if answers.get("reinstall"):
        parts = [copy_partition(p) for p in answers["reinstall"]]
        if encrypt:
            write_secret(OLD_KEY_FILE, answers["old_secret"])
        disk_changed = True
        for part in recreated_partitions(parts):
            write_definitions(parts, source, encrypt, reset=[part])
            title = f"Creating {part.mount} again"
            if part.mount == "/":
                title += " and copying Legion (several minutes)"
            run_long(args + ["--empty=refuse", "--factory-reset=yes", f"--copy-source={source}", disk],
                     title, ui)
            wait_for_udev()
    else:
        parts = new_partitions(answers["layout"])
        write_definitions(parts, source, encrypt)
        disk_changed = True
        run_long(args + ["--empty=force", f"--copy-source={source}", disk],
                 "Partitioning the disk and copying Legion (several minutes)", ui)
    find_partitions(disk, parts)
    return parts


def wait_for_udev():
    """Waits until udev has handled the partitions that systemd-repart
    changed. udev watches disks, and when systemd-repart closes the disk it
    reads the partition table again: the partitions disappear for a moment
    and come back (a second kernel line "nvme0n1: p1 p2" 4 ms after the
    first). udevadm settle right away may return before that starts, so it
    waits a moment first."""
    time.sleep(UDEV_DELAY)
    run(["udevadm", "settle"])


def copy_partition(found):
    part = Partition(found.mount, found.size)
    for name in ("label", "keep", "encrypted", "node", "number", "start", "uuid"):
        setattr(part, name, getattr(found, name))
    return part


def matching_rows(part, rows):
    """The lsblk rows of a partition: a kept one by its PARTUUID, a new one
    by its type, and a folder of your own also by its name."""
    if part.keep:
        return [r for r in rows if r.get("partuuid") == part.uuid]
    return [r for r in rows if (r.get("parttype") or "").lower() == TYPES[part.kind]
            and (part.kind != "linux-generic" or r.get("partlabel") == part.label)]


def find_partitions(disk, parts):
    """Finds the device of every partition after systemd-repart. If lsblk
    does not show them yet, for example while udev reads the partition
    table again, it asks again for up to PARTITIONS_TIMEOUT seconds."""
    deadline = time.monotonic() + PARTITIONS_TIMEOUT
    while True:
        wait_for_udev()
        _, rows = partition_table(disk)
        found = [(part, matching_rows(part, rows)) for part in parts]
        missing = [part.mount for part, matches in found if len(matches) != 1]
        if not missing:
            break
        if time.monotonic() > deadline:
            log("lsblk: " + json.dumps(rows))
            raise InstallError(f"The partition for {missing[0]} was not found on {disk}.")
        log(f"lsblk does not show {', '.join(missing)} on {disk} yet")
    for part, matches in found:
        part.node, part.number = matches[0]["path"], matches[0].get("partn")
        log(f"partition {part.number} {part.node}: {part!r}")


def copy_access(source, target):
    """Gives the top folder of a new partition the mode and owner of its
    folder on the USB stick. systemd-repart 257 copies the files with
    mkfs.ext4 -d, which leaves the top folder 0755 and owned by root: wrong
    for /var/tmp, which needs 1777."""
    try:
        status = os.stat(source)
    except FileNotFoundError:
        return
    os.chown(target, status.st_uid, status.st_gid)
    os.chmod(target, stat.S_IMODE(status.st_mode))
    log(f"top folder {target}: {stat.filemode(status.st_mode)} {status.st_uid}:{status.st_gid}")


def mount_target(parts, source, encrypt):
    """Mounts the new system in TARGET with every partition on its folder,
    so that files the installer writes, such as your home folder, land on
    the right partition."""
    for part in parts:
        part.device = part.node
        if encrypt and part.kind not in ("esp", "swap"):
            name = TARGET_VOLUME if part.mount == "/" else f"{TARGET_VOLUME}-{part.number}"
            run(["systemd-cryptsetup", "attach", name, part.node, OLD_KEY_FILE if part.keep else KEY_FILE,
                 "luks,tries=1"])
            cleanup_steps.append(lambda name=name: run(["systemd-cryptsetup", "detach", name], check=False))
            part.device = Path("/dev/mapper") / name
    root = next(p for p in parts if p.mount == "/")
    TARGET.mkdir(exist_ok=True)
    run(["mount", root.device, TARGET])
    cleanup_steps.append(lambda: run(["umount", "--recursive", TARGET], check=False))
    esp = next(p for p in parts if p.kind == "esp")
    (TARGET / "efi").mkdir(exist_ok=True)
    run(["mount", esp.device, TARGET / "efi"])
    # Folders inside others come after them: /var before /var/tmp.
    for part in sorted((p for p in parts if p.kind not in ("root", "esp", "swap")),
                       key=lambda p: p.mount.count("/")):
        where = TARGET / part.mount[1:]
        where.mkdir(parents=True, exist_ok=True)
        run(["mount", part.device, where])
        if not part.keep:
            copy_access(source / part.mount[1:], where)
    # What programs in the new system need: kernel interfaces, devices (with
    # the EFI variables under /sys) and the udev database.
    run(["mount", "-t", "proc", "proc", TARGET / "proc"])
    for path in ("sys", "dev"):
        run(["mount", "--rbind", f"/{path}", TARGET / path])
        run(["mount", "--make-rslave", TARGET / path])
    run(["mount", "-t", "tmpfs", "-o", "mode=0755,nosuid,nodev", "tmpfs", TARGET / "run"])
    (TARGET / "run/udev").mkdir()
    run(["mount", "--bind", "/run/udev", TARGET / "run/udev"])


def write_target_file(relative, text, mode=0o644):
    path = TARGET / relative
    if path.is_symlink():
        path.unlink()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    os.chmod(path, mode)
    log(f"wrote /{relative}")


def mask_target_unit(relative):
    mask = TARGET / relative
    mask.unlink(missing_ok=True)
    mask.parent.mkdir(parents=True, exist_ok=True)
    mask.symlink_to("/dev/null")
    log(f"masked /{relative}")


def copy_kernels(kernels):
    for version in kernels:
        for stem in ("vmlinuz", "config", "System.map"):
            source = SOURCE_ESP / f"{stem}-{version}"
            if source.is_file():
                target = TARGET / "boot" / source.name
                shutil.copyfile(source, target)
                os.chmod(target, 0o644)
                log(f"copied /boot/{source.name}")


def file_system_uuid(node):
    """The UUID of the file system or LUKS2 header on a partition, read from
    the partition itself rather than from the udev database."""
    return run(["blkid", "--probe", "--match-tag", "UUID", "--output", "value", node], capture=True).strip()


def add_mount_entries(parts, encrypt):
    """Lines in /etc/fstab, and on an encrypted disk in /etc/crypttab, for
    the partitions of folders of your own: systemd-gpt-auto-generator mounts
    only the partition types it knows. Their keys are in
    /etc/cryptsetup-keys.d/ (set_up_partition_keys); dracut leaves crypttab
    out of the generic initrd (D-57), so the system opens them after start."""
    own = [p for p in parts if p.kind == "linux-generic"]
    if not own:
        return
    fstab = TARGET / "etc/fstab"
    text = fstab.read_text() if fstab.is_file() else ""
    text += "# Partitions of folders of your own, from the Legion installer (D-80).\n"
    crypttab = ""
    for part in own:
        uuid_ = file_system_uuid(part.node)
        if not uuid_:
            raise InstallError(f"The UUID of {part.node} ({part.mount}) was not found.")
        if encrypt:
            crypttab += f"{part.volume} UUID={uuid_} /etc/cryptsetup-keys.d/{part.volume}.key luks\n"
            text += f"/dev/mapper/{part.volume} {part.mount} ext4 defaults 0 2\n"
        else:
            text += f"UUID={uuid_} {part.mount} ext4 defaults 0 2\n"
    write_target_file("etc/fstab", text)
    if crypttab:
        path = TARGET / "etc/crypttab"
        old = path.read_text() if path.is_file() else ""
        write_target_file("etc/crypttab", old + "# Encrypted partitions of folders of your own, from the "
                                                "Legion installer (D-80).\n" + crypttab)


def add_account(answers):
    """Your account, in the sudo group. In a reinstallation that keeps
    /home, the account gets the number (UID) and group of its folder there,
    so that your files stay yours."""
    full_name, user, password = answers["account"]
    args = ["useradd", "--comment", full_name, "--groups", ",".join(ACCOUNT_GROUPS), "--shell", "/bin/bash"]
    owner = answers.get("home_owner")
    if owner:
        uid, gid = owner
        groups = {line.split(":")[2]: line.split(":")[0]
                  for line in (TARGET / "etc/group").read_text().splitlines() if line.count(":") >= 3}
        if str(gid) not in groups:
            run(["groupadd", "--gid", gid, user], chroot=True)
        args += ["--uid", uid, "--gid", groups.get(str(gid), user)]
    args.append("--no-create-home" if (TARGET / "home" / user).is_dir() else "--create-home")
    run(args + [user], chroot=True)
    run(["chpasswd"], chroot=True, input=f"{user}:{password}\n")
    run(["passwd", "--lock", "root"], chroot=True)


def configure(answers, parts, ui):
    write_target_file("etc/hostname", answers["hostname"] + "\n")

    locales = load_locales()
    language = answers["language"]
    generate = [locales["en_US.UTF-8"]] + ([locales[language]] if language != "en_US.UTF-8" else [])
    write_target_file("etc/locale.gen", "".join(f"{line}\n" for line in generate))
    write_target_file("etc/locale.conf", f"LANG={language}\n")
    run(["locale-gen"], chroot=True)

    layout, variant, options = keyboard_settings(*answers["keyboard"])
    write_target_file("etc/default/keyboard",
                      "# Keyboard layout of the console and of the desktop, see keyboard(5).\n"
                      'XKBMODEL="pc105"\n'
                      f'XKBLAYOUT="{layout}"\n'
                      f'XKBVARIANT="{variant}"\n'
                      f'XKBOPTIONS="{options}"\n'
                      'BACKSPACE="guess"\n')
    # The console and the disk passphrase prompt of the initrd use the keymap
    # that console-setup derives from this file (dracut module console-setup,
    # loaded by legion-console-setup from legion-boot).
    if run(["setupcon", "--save-only"], chroot=True, check=False) != 0:
        ui.note("Warning: could not prepare the console keymap; see the log.")

    localtime = TARGET / "etc/localtime"
    localtime.unlink(missing_ok=True)
    localtime.symlink_to(f"../usr/share/zoneinfo/{answers['timezone']}")
    log(f"time zone {answers['timezone']}")

    add_account(answers)

    swap, size = answers["swap"]
    if swap in ("zram", "both"):
        mask = TARGET / ZRAM_MASK
        if mask.is_symlink() and os.readlink(mask) == "/dev/null":
            mask.unlink()
            log(f"removed /{ZRAM_MASK}, zram is on")
    if swap in ("file", "both"):
        run(["mkswap", "--file", "--size", f"{size}G", "/swapfile"], chroot=True)
        fstab = TARGET / "etc/fstab"
        text = fstab.read_text() if fstab.is_file() else ""
        text += "# Swap file from the Legion installer (D-48, D-59).\n/swapfile none swap defaults 0 0\n"
        write_target_file("etc/fstab", text)

    add_mount_entries(parts, answers["encrypt"])

    if answers["encrypt"]:
        for part in parts:
            if part.mount == "/":
                mask_target_unit(GROWFS_ROOT_MASK)
            elif part.kind in ("home", "srv", "var", "tmp"):
                mask_target_unit(GROWFS_MASK.format(part.volume))

    installed = [p for p in LIVE_PACKAGES
                 if run(["dpkg-query", "--show", "--showformat=${Status}", p],
                        chroot=True, capture=True, check=False).endswith(" installed")]
    if installed:
        run(["dpkg", "--purge", *installed], chroot=True)


def install_boot_loader(kernels, ui):
    # bootctl writes the boot entry "Linux Boot Manager" into the firmware
    # (EFI variables). It does that only without --root, hence the chroot.
    run(["bootctl", "install", "--esp-path=/efi"], chroot=True)
    for version in kernels:
        run_long(["kernel-install", "add", version, f"/boot/vmlinuz-{version}"],
                 f"Building the initrd and the boot menu entry of kernel {version}", ui, chroot=True)
    entries = sorted(p.name for p in (TARGET / "efi/loader/entries").glob("*.conf"))
    if not entries:
        raise InstallError("kernel-install did not create a boot menu entry.")
    log(f"boot menu entries: {' '.join(entries)}")


def drop_page_cache():
    """Makes the next reads come from the disk, not from memory."""
    run(["sync"])
    Path("/proc/sys/vm/drop_caches").write_text("3\n")


def verify_copy():
    """Package files of the new system that differ from their packages, as
    lines of dpkg --verify."""
    drop_page_cache()
    output = run(["dpkg", f"--root={TARGET}", "--verify"], capture=True, check=False)
    # Lines of package files, as in legion-test: changed configuration files
    # (flag c) are left out, and so is os-release, which mkosi changes.
    failed = [line for line in output.splitlines()
              if re.match(r"^(missing|[?.\w]{9}) +/", line)
              and not line.rstrip().endswith(" /usr/lib/os-release")]
    log(f"dpkg --verify: {len(failed)} files")
    for line in failed:
        log(f"  {line}")
    return failed


def key_slots(partition):
    """Slots of the LUKS2 header as listed by systemd-cryptenroll."""
    output = run(["systemd-cryptenroll", partition], capture=True)
    rows = [line.split() for line in output.splitlines()]
    return [row[:2] for row in rows if len(row) >= 2 and row[0].isdigit()]


def enroll_security_key(root, ask_pin=None):
    """Adds a FIDO2 security key to the encrypted partition. The user touches
    the key when it blinks, maybe twice. Without ask_pin, systemd-cryptenroll
    asks for the PIN of the key in the terminal. The window has no terminal,
    so it passes ask_pin(message, again) and the installer answers as a
    password agent. A PIN file (credential) is not used: with a wrong PIN,
    systemd-cryptenroll 257 would try it again and again until the key
    blocks its PIN. Returns whether the key was added."""
    args = ["systemd-cryptenroll", f"--unlock-key-file={KEY_FILE}", "--fido2-device=auto", root]
    if ask_pin is None:
        return run(args, interactive=True, check=False) == 0
    return run_answering_passwords(args, ask_pin) == 0


def set_up_unlocking(root, passphrase, use_fido2, ui):
    """Replaces the temporary key of systemd-repart on the root partition
    with a recovery key, the passphrase and optionally a FIDO2 security key.
    Returns the recovery key and whether a security key was added."""
    ui.step("Adding a recovery key")
    recovery = run(["systemd-cryptenroll", f"--unlock-key-file={KEY_FILE}", "--recovery-key", root],
                   capture=True, hide_stderr=True).strip()
    log("recovery key enrolled")
    ui.check_recovery_key(recovery)

    security_key = False
    if use_fido2:
        ui.step("Adding the security key")
        security_key = ui.add_security_key(lambda ask_pin=None: enroll_security_key(root, ask_pin))
        log("FIDO2 key enrolled" if security_key else "FIDO2 key skipped")

    # The temporary key of systemd-repart is in slot 0, the only slot without
    # a token so far. The passphrase replaces it.
    ui.step("Setting the disk passphrase")
    slots = key_slots(root)
    if ["0", "password"] not in slots or sum(1 for s in slots if s[1] == "password") != 1:
        raise InstallError(f"Unexpected key slots on {root}: {slots}")
    run(["systemd-cryptenroll", f"--unlock-key-file={KEY_FILE}", "--password", "--wipe-slot=0", root],
        env={"NEWPASSWORD": passphrase})
    slots = key_slots(root)
    log(f"key slots: {slots}")
    if any(s[0] == "0" for s in slots) or not any(s[1] == "password" for s in slots):
        raise InstallError(f"The disk passphrase was not set as expected: {slots}")
    return recovery, security_key


def set_up_partition_keys(parts, passphrase, recovery, ui):
    """Keys of the encrypted partitions other than the root partition (D-79,
    D-80). Each gets a random key that the computer reads at start from
    /etc/cryptsetup-keys.d/<volume>.key on the root partition. It is enrolled
    as a recovery key, because systemd-cryptenroll 257 gives only those (and
    hardware keys) a fast key derivation, and it comes first among the
    slots, which are tried in order. The passphrase and the recovery key of
    the root partition open the partition too, for a reinstallation or in an
    emergency. The temporary key, or the keys of a kept partition from before,
    are removed."""
    others = [p for p in parts if p.kind not in ("esp", "root")]
    if not others:
        return
    ui.step("Setting up the keys of the other partitions")
    folder = TARGET / "etc/cryptsetup-keys.d"
    folder.mkdir(mode=0o700, exist_ok=True)
    os.chmod(folder, 0o700)
    for part in others:
        old = [slot for slot, _ in key_slots(part.node)]
        unlock = OLD_KEY_FILE if part.keep else KEY_FILE
        key = run(["systemd-cryptenroll", f"--unlock-key-file={unlock}", "--recovery-key", part.node],
                  capture=True, hide_stderr=True).strip()
        if not key:
            raise InstallError(f"No key was made for {part.mount}.")
        key_file = folder / f"{part.volume}.key"
        write_secret(key_file, key)
        log(f"key of {part.mount}: /etc/cryptsetup-keys.d/{key_file.name}")
        run(["systemd-cryptenroll", f"--unlock-key-file={key_file}", "--password", part.node],
            env={"NEWPASSWORD": passphrase})
        run(["systemd-cryptenroll", f"--unlock-key-file={key_file}", "--password",
             f"--wipe-slot={','.join(old)}", part.node], env={"NEWPASSWORD": recovery})
        slots = key_slots(part.node)
        log(f"key slots of {part.mount}: {slots}")
        if (sorted(kind for _, kind in slots) != ["password", "password", "recovery"]
                or any(slot in old for slot, _ in slots)):
            raise InstallError(f"The keys of {part.mount} were not set as expected: {slots}")


def save_log():
    if (TARGET / "var/log").is_dir():
        try:
            shutil.copyfile(LOG_FILE, TARGET / "var/log/legion-install.log")
            os.chmod(TARGET / "var/log/legion-install.log", 0o600)
        except OSError as error:
            log(f"could not copy the log: {error}")


def cleanup():
    while cleanup_steps:
        step = cleanup_steps.pop()
        try:
            step()
        except Exception as error:  # cleanup must go on
            log(f"cleanup: {error}")
    for path in (SOURCE_ESP, SOURCE):
        if os.path.ismount(path):
            run(["umount", path], check=False)
    for path in (KEY_FILE, OLD_KEY_FILE, CHECK_KEY_FILE):
        path.unlink(missing_ok=True)


def install(answers, ui):
    """Installs Legion with the answers: disk (from candidate_disks), layout
    (for an erased disk) or reinstall (the partitions from find_legion),
    language, keyboard (layout, variant), timezone, hostname, account (full
    name, user name, password), home_owner (uid and gid of the folder of the
    account in a kept /home, or None), encrypt, passphrase, old_secret (the
    passphrase or recovery key of kept encrypted partitions), fido2 and swap
    (choice, size in GiB). ui is a Frontend. Raises InstallError when the
    installation fails; disk_changed then tells whether the disk was changed
    already. Returns the root partition, the time the installation took and
    whether a security key was added."""
    disk = answers["disk"]["path"]
    layout, variant = answers["keyboard"]
    _, user, _ = answers["account"]
    swap, size = answers["swap"]
    start_log()
    plan = (f"reinstall {answers['reinstall']}" if answers.get("reinstall")
            else f"layout {answers['layout']}")
    log(f"disk {disk} ({disk_id(disk)}), {plan}, language {answers['language']}, "
        f"keyboard {layout}:{variant}, time zone {answers['timezone']}, hostname {answers['hostname']}, "
        f"user {user} {answers.get('home_owner')}, swap {swap} {size}, encryption {answers['encrypt']}, "
        f"fido2 {answers['fido2']}")
    try:
        if not answers.get("reinstall"):
            problems = check_layout(answers["layout"], answers["disk"]["size"])
            if problems:
                raise InstallError(" ".join(problems))
        boot_partition = find_boot_partition()
        if not boot_partition:
            raise InstallError("The Legion USB stick is not connected. Plug it in and run the installer again.")
        boot_disk = parent_disk(boot_partition)
        if disk == boot_disk:
            raise InstallError(f"{disk} is the Legion USB stick.")
        busy = in_use(block_devices(disk)[0])
        if busy:
            raise InstallError(f"Parts of {disk} are in use: {', '.join(busy)}. Unmount them, "
                               "or restart the live session, and run the installer again.")
        private_mounts()

        started = time.monotonic()
        ui.step("Reading Legion from the USB stick")
        if not keep_awake():
            ui.note("the computer may go to sleep: keep the lid open until the end")
        source, kernels = mount_source(boot_partition, boot_disk)
        check_account(source, answers)
        # The machine ID of the new system. systemd-repart derives the UUID
        # of /var from it (--seed), as systemd-gpt-auto-generator expects.
        machine_id = uuid.uuid4().hex
        parts = partition_and_copy(answers, source, machine_id, ui)
        mount_target(parts, source, answers["encrypt"])
        copy_kernels(kernels)
        ui.step("Setting up the new system")
        configure(answers, parts, ui)
        ui.step("Installing the boot loader")
        install_boot_loader(kernels, ui)
        # After bootctl and kernel-install, so that the boot menu entries
        # keep the name legion from os-release (/etc/kernel/entry-token), as
        # before this file had the machine ID.
        write_target_file("etc/machine-id", machine_id + "\n", 0o444)
        ui.step("Checking the copied files (dpkg --verify)")
        failed = verify_copy()
        if not failed:
            ui.note("all package files are correct")
        elif not ui.keep_damaged_copy(failed):
            raise InstallError("The installation was stopped after dpkg --verify.")
        security_key = False
        root = next(p for p in parts if p.mount == "/")
        if answers["encrypt"]:
            recovery, security_key = set_up_unlocking(root.node, answers["passphrase"], answers["fido2"], ui)
            set_up_partition_keys(parts, answers["passphrase"], recovery, ui)
        took = elapsed(started)
        log(f"installation finished after {took}")
        save_log()
        return {"root": root.node, "time": took, "security_key": security_key}
    finally:
        cleanup()
        log("end")
